--
-- PostgreSQL database dump
--

\restrict NRlzwTe2eo3F7rZHIjHeJgmBPEszYauRCY27zKSOcqqsdEove0ZgzY3fhycguxY

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: carga_estado_enum; Type: TYPE; Schema: public; Owner: tmsdb
--

CREATE TYPE public.carga_estado_enum AS ENUM (
    'borrador',
    'propuestas_pendientes',
    'propuesto',
    'propuesta_aceptada',
    'asignado',
    'listo_para_recoger',
    'recogido',
    'en_transito',
    'llegado_al_destino',
    'en_reparto_final',
    'entregado',
    'reprogramado',
    'cancelado'
);


ALTER TYPE public.carga_estado_enum OWNER TO tmsdb;

--
-- Name: carga_via_enum; Type: TYPE; Schema: public; Owner: tmsdb
--

CREATE TYPE public.carga_via_enum AS ENUM (
    'maritima',
    'aerea',
    'terrestre',
    'ferroviaria',
    'ultima_milla',
    'escatolina'
);


ALTER TYPE public.carga_via_enum OWNER TO tmsdb;

--
-- Name: cita_taller_estado_enum; Type: TYPE; Schema: public; Owner: tmsdb
--

CREATE TYPE public.cita_taller_estado_enum AS ENUM (
    'pendiente',
    'aprobada',
    'rechazada',
    'en_progreso',
    'completada',
    'cancelada'
);


ALTER TYPE public.cita_taller_estado_enum OWNER TO tmsdb;

--
-- Name: cuenta_bancaria_currency_enum; Type: TYPE; Schema: public; Owner: tmsdb
--

CREATE TYPE public.cuenta_bancaria_currency_enum AS ENUM (
    'USD',
    'EUR'
);


ALTER TYPE public.cuenta_bancaria_currency_enum OWNER TO tmsdb;

--
-- Name: pago_estado_enum; Type: TYPE; Schema: public; Owner: tmsdb
--

CREATE TYPE public.pago_estado_enum AS ENUM (
    'REGISTRADO',
    'EN_PROCESO',
    'RECHAZADO',
    'ACEPTADO'
);


ALTER TYPE public.pago_estado_enum OWNER TO tmsdb;

--
-- Name: prestatario_contenedor_enum; Type: TYPE; Schema: public; Owner: tmsdb
--

CREATE TYPE public.prestatario_contenedor_enum AS ENUM (
    '20',
    '40',
    'Isotanque de 20"',
    'Isotanque de 40"'
);


ALTER TYPE public.prestatario_contenedor_enum OWNER TO tmsdb;

--
-- Name: prestatario_servicios_enum; Type: TYPE; Schema: public; Owner: tmsdb
--

CREATE TYPE public.prestatario_servicios_enum AS ENUM (
    'maritima',
    'aerea',
    'terrestre',
    'ferroviaria',
    'ultima_milla',
    'escatolina'
);


ALTER TYPE public.prestatario_servicios_enum OWNER TO tmsdb;

--
-- Name: prestatario_tipocarga_enum; Type: TYPE; Schema: public; Owner: tmsdb
--

CREATE TYPE public.prestatario_tipocarga_enum AS ENUM (
    'Seco',
    'Refrigerado',
    'Carga general'
);


ALTER TYPE public.prestatario_tipocarga_enum OWNER TO tmsdb;

--
-- Name: prestatarios_contenedor_enum; Type: TYPE; Schema: public; Owner: tmsdb
--

CREATE TYPE public.prestatarios_contenedor_enum AS ENUM (
    '20',
    '40'
);


ALTER TYPE public.prestatarios_contenedor_enum OWNER TO tmsdb;

--
-- Name: prestatarios_tipocarga_enum; Type: TYPE; Schema: public; Owner: tmsdb
--

CREATE TYPE public.prestatarios_tipocarga_enum AS ENUM (
    'Seco',
    'Refrigerado',
    'Carga general'
);


ALTER TYPE public.prestatarios_tipocarga_enum OWNER TO tmsdb;

--
-- Name: reserva_state_enum; Type: TYPE; Schema: public; Owner: tmsdb
--

CREATE TYPE public.reserva_state_enum AS ENUM (
    'Ordenado',
    'En Producción',
    'Producido',
    'Embarcado',
    'En Transito',
    'Facturado',
    'Entregado',
    'Cancelado'
);


ALTER TYPE public.reserva_state_enum OWNER TO tmsdb;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: address_details; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.address_details (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.502'::timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.503'::timestamp without time zone NOT NULL,
    _deleted_at timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    name character varying,
    description character varying,
    "isUsed" boolean DEFAULT false NOT NULL,
    "homeNumber" character varying,
    "streetName" character varying,
    address character varying,
    "postalCode" character varying,
    municipality_id uuid
);


ALTER TABLE public.address_details OWNER TO tmsdb;

--
-- Name: calendar; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.calendar (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.502'::timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.503'::timestamp without time zone NOT NULL,
    _deleted_at timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    name character varying,
    description character varying,
    fecha timestamp without time zone NOT NULL,
    inicio integer NOT NULL,
    fin integer,
    "fullDay" boolean NOT NULL,
    "user" character varying,
    state character varying NOT NULL,
    "isService" boolean
);


ALTER TABLE public.calendar OWNER TO tmsdb;

--
-- Name: carga; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.carga (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.502'::timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.503'::timestamp without time zone NOT NULL,
    _deleted_at timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    name character varying,
    description character varying,
    order_id character varying NOT NULL,
    carga_serie character varying,
    remitente_dni character varying NOT NULL,
    remitente_nombre character varying NOT NULL,
    direccion character varying NOT NULL,
    emisor_dni character varying NOT NULL,
    emisor_nombre character varying NOT NULL,
    emisor_direccion character varying,
    cant_bultos integer NOT NULL,
    peso_total integer NOT NULL,
    vol_bulto integer NOT NULL,
    origen_string character varying NOT NULL,
    destino_string character varying NOT NULL,
    autorizado_recoger character varying NOT NULL,
    tipo_carga character varying NOT NULL,
    precio integer NOT NULL,
    tarifabase integer NOT NULL,
    volumen integer NOT NULL,
    impuesto integer NOT NULL,
    comision integer NOT NULL,
    origen uuid,
    destino uuid,
    cliente_id uuid NOT NULL,
    estado public.carga_estado_enum DEFAULT 'propuestas_pendientes'::public.carga_estado_enum NOT NULL,
    via public.carga_via_enum,
    status_reason text,
    status_date timestamp without time zone,
    pod_dni_front_base64 text,
    pod_dni_back_base64 text,
    pod_signed boolean DEFAULT false NOT NULL,
    pod_signature_confirmed boolean DEFAULT false NOT NULL,
    assigned_prestatario_id uuid,
    "fechaRegistro" timestamp with time zone DEFAULT now() NOT NULL,
    fecha_emision timestamp with time zone,
    no_orden character varying,
    comprador_interno character varying,
    autorizado_lugar character varying,
    fecha_autorizada timestamp with time zone,
    representante_nombre character varying,
    representante_carnet character varying,
    representante_cargo character varying,
    firma character varying,
    tipo_producto character varying,
    contenedor_siglas character varying,
    nombre_destinatario character varying,
    nombre_buque character varying,
    mfto_no character varying,
    bl_no character varying,
    dm_no character varying,
    vehiculo_pertenece_a character varying,
    conducido_por character varying,
    chapa_no character varying,
    lot_no character varying,
    hoja_ruta_no character varying,
    carta_porte_no character varying,
    chapa_tractivo_no character varying,
    remolque_no character varying,
    conductor_carnet_no character varying,
    licencia_conduccion_no character varying,
    basificado_en character varying
);


ALTER TABLE public.carga OWNER TO tmsdb;

--
-- Name: cita_taller; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.cita_taller (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.502'::timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.503'::timestamp without time zone NOT NULL,
    _deleted_at timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    fecha_hora_inicio timestamp with time zone NOT NULL,
    fecha_hora_fin timestamp with time zone NOT NULL,
    estado public.cita_taller_estado_enum DEFAULT 'pendiente'::public.cita_taller_estado_enum NOT NULL,
    es_servicio_escatolina boolean DEFAULT false NOT NULL,
    peso_kg numeric(10,2),
    volumen_m3 numeric(10,2),
    fecha_estimada_viaje timestamp with time zone,
    licencia_operativa character varying(50),
    precio_servicio_base numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    precio_flete_escatolina numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    precio_total numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    fecha_solicitud timestamp with time zone DEFAULT now() NOT NULL,
    fecha_respuesta_taller timestamp with time zone,
    motivo_rechazo text,
    notas_adicionales text,
    taller_id uuid,
    cliente_id uuid,
    servicio_id uuid,
    origen_id uuid,
    destino_id uuid,
    tipo_carga_id uuid,
    tipo_transporte_id uuid
);


ALTER TABLE public.cita_taller OWNER TO tmsdb;

--
-- Name: cliente; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.cliente (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.502'::timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.503'::timestamp without time zone NOT NULL,
    _deleted_at timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    company character varying,
    contact_name character varying,
    contact_phone character varying,
    tax_id character varying,
    address character varying,
    user_id uuid NOT NULL,
    modalidad character varying
);


ALTER TABLE public.cliente OWNER TO tmsdb;

--
-- Name: comercial; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.comercial (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.502'::timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.503'::timestamp without time zone NOT NULL,
    _deleted_at timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    name character varying,
    description character varying,
    apellido character varying NOT NULL,
    correo character varying NOT NULL,
    telefono character varying NOT NULL
);


ALTER TABLE public.comercial OWNER TO tmsdb;

--
-- Name: configuracion; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.configuracion (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.502'::timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.503'::timestamp without time zone NOT NULL,
    _deleted_at timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    "from" character varying NOT NULL,
    "to" character varying NOT NULL,
    "porcientoConfReserva" integer NOT NULL,
    "porcientoMinPrice" integer NOT NULL,
    impuesto integer NOT NULL
);


ALTER TABLE public.configuracion OWNER TO tmsdb;

--
-- Name: country; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.country (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.502'::timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.503'::timestamp without time zone NOT NULL,
    _deleted_at timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    name character varying,
    description character varying,
    "isUsed" boolean DEFAULT false NOT NULL,
    code character varying NOT NULL,
    "numericCode" integer
);


ALTER TABLE public.country OWNER TO tmsdb;

--
-- Name: cuenta_bancaria; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.cuenta_bancaria (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.502'::timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.503'::timestamp without time zone NOT NULL,
    _deleted_at timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    beneficiario character varying NOT NULL,
    "direccionBeneficiario" character varying NOT NULL,
    "nombreBanco" character varying NOT NULL,
    "direccionBanco" character varying NOT NULL,
    codigo character varying NOT NULL,
    currency public.cuenta_bancaria_currency_enum NOT NULL,
    "numeroCuenta" character varying NOT NULL
);


ALTER TABLE public.cuenta_bancaria OWNER TO tmsdb;

--
-- Name: customer; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.customer (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.502'::timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.503'::timestamp without time zone NOT NULL,
    _deleted_at timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    name character varying,
    description character varying,
    email character varying,
    "addessLineOne" character varying,
    "addessLineTwo" character varying,
    "cityTown" character varying,
    "postalCode" character varying,
    planes_id uuid
);


ALTER TABLE public.customer OWNER TO tmsdb;

--
-- Name: customer_cuenta; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.customer_cuenta (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.502'::timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.503'::timestamp without time zone NOT NULL,
    _deleted_at timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    name character varying,
    description character varying,
    customer_id uuid,
    cuenta_bancaria_id uuid
);


ALTER TABLE public.customer_cuenta OWNER TO tmsdb;

--
-- Name: destino; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.destino (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.502'::timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.503'::timestamp without time zone NOT NULL,
    _deleted_at timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    name character varying,
    description character varying
);


ALTER TABLE public.destino OWNER TO tmsdb;

--
-- Name: doccarga; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.doccarga (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.502'::timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.503'::timestamp without time zone NOT NULL,
    _deleted_at timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    name character varying,
    description character varying,
    file character varying NOT NULL,
    carga uuid
);


ALTER TABLE public.doccarga OWNER TO tmsdb;

--
-- Name: locality; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.locality (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.502'::timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.503'::timestamp without time zone NOT NULL,
    _deleted_at timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    name character varying,
    description character varying,
    "isUsed" boolean DEFAULT false NOT NULL,
    municipality_id uuid
);


ALTER TABLE public.locality OWNER TO tmsdb;

--
-- Name: modalidad; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.modalidad (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.502'::timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.503'::timestamp without time zone NOT NULL,
    _deleted_at timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    name character varying,
    description character varying,
    detalles character varying NOT NULL,
    caracteristicas json
);


ALTER TABLE public.modalidad OWNER TO tmsdb;

--
-- Name: municipality; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.municipality (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.502'::timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.503'::timestamp without time zone NOT NULL,
    _deleted_at timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    name character varying,
    description character varying,
    "isUsed" boolean DEFAULT false NOT NULL,
    province_id uuid
);


ALTER TABLE public.municipality OWNER TO tmsdb;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.notifications (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.502'::timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.503'::timestamp without time zone NOT NULL,
    _deleted_at timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    title character varying(255) NOT NULL,
    read boolean DEFAULT false NOT NULL,
    type character varying(50),
    link character varying(500),
    meta jsonb,
    user_origin_id uuid,
    user_target_id uuid NOT NULL,
    message text
);


ALTER TABLE public.notifications OWNER TO tmsdb;

--
-- Name: origen; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.origen (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.502'::timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.503'::timestamp without time zone NOT NULL,
    _deleted_at timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    name character varying,
    description character varying
);


ALTER TABLE public.origen OWNER TO tmsdb;

--
-- Name: pago; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.pago (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.502'::timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.503'::timestamp without time zone NOT NULL,
    _deleted_at timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    name character varying,
    description character varying,
    "facturaNumero" character varying(100) NOT NULL,
    monto numeric(10,2) NOT NULL,
    "fechaRegistro" date NOT NULL,
    "fechaFactura" date NOT NULL,
    estado public.pago_estado_enum DEFAULT 'REGISTRADO'::public.pago_estado_enum NOT NULL,
    "customerId" uuid,
    comercial_id uuid,
    "cuentaBancariaOrigen" uuid,
    reserva_id uuid
);


ALTER TABLE public.pago OWNER TO tmsdb;

--
-- Name: peticion; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.peticion (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "nombreEntidad" character varying(200) NOT NULL,
    "nombreCarga" character varying(200) NOT NULL,
    peso numeric NOT NULL,
    volumen numeric,
    origen character varying(200) NOT NULL,
    destino character varying(200) NOT NULL,
    "tipoCarga" character varying(100) NOT NULL,
    status character varying(20) DEFAULT 'abierta'::character varying NOT NULL,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    cliente_id uuid NOT NULL,
    assigned_proposal_id uuid,
    via character varying(32),
    "origenDireccion" text,
    "destinoDireccion" text,
    "distanciaKm" numeric,
    "precioEstimado" numeric,
    transportista_prestatario_id uuid
);


ALTER TABLE public.peticion OWNER TO tmsdb;

--
-- Name: plan-servicio-cliente; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public."plan-servicio-cliente" (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.502'::timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.503'::timestamp without time zone NOT NULL,
    _deleted_at timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    servicio_id uuid,
    plan_id uuid
);


ALTER TABLE public."plan-servicio-cliente" OWNER TO tmsdb;

--
-- Name: plan-servicio-prestatario; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public."plan-servicio-prestatario" (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.502'::timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.503'::timestamp without time zone NOT NULL,
    _deleted_at timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL
);


ALTER TABLE public."plan-servicio-prestatario" OWNER TO tmsdb;

--
-- Name: planes; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.planes (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.502'::timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.503'::timestamp without time zone NOT NULL,
    _deleted_at timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    name character varying,
    description character varying,
    precio integer NOT NULL,
    prestatario boolean NOT NULL
);


ALTER TABLE public.planes OWNER TO tmsdb;

--
-- Name: prestatario; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.prestatario (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.502'::timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.503'::timestamp without time zone NOT NULL,
    _deleted_at timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    "tipoCarga" public.prestatario_tipocarga_enum,
    contenedor public.prestatario_contenedor_enum,
    transportes jsonb,
    ayudantes jsonb,
    "cargasEspeciales" jsonb,
    rating double precision,
    licencia jsonb,
    "user" uuid,
    "maxWeight" numeric,
    "maxVolume" numeric,
    name character varying,
    servicios public.prestatario_servicios_enum[],
    conditions text,
    "metrosDisponiblesAlquiler" numeric,
    "alturaMAlquiler" numeric,
    "serviciosPrestAlquiler" jsonb,
    "talleresNumTecnicos" numeric,
    "talleresHorario" text,
    "talleresServicios" jsonb,
    "talleresCapacidadVehiculos" numeric,
    "gpsProviders" jsonb,
    "gpsDevicesAvailable" numeric,
    "gpsPlans" text,
    "gpsIntegrationApi" boolean DEFAULT false NOT NULL,
    "habitacionesDisponibles" numeric,
    "capacidadPersonas" numeric,
    "precioNochePromedio" numeric,
    "tipoHabitaciones" jsonb,
    "serviciosIncluidosAlojamiento" jsonb,
    "precioTerrestre" jsonb,
    "consumoGasolina" numeric,
    "tiposVehiculos" jsonb,
    "capacidadPorTipo" jsonb,
    disponible boolean DEFAULT true NOT NULL,
    "disponibilidadDesde" timestamp with time zone,
    "disponibilidadHasta" timestamp with time zone,
    "zonaCobertura" jsonb,
    "cantidadCamiones" numeric,
    "talleresDireccion" text,
    "talleresPrecios" jsonb,
    "talleresReservaCitas" boolean DEFAULT false NOT NULL,
    "talleresHorarioInicio" text,
    "talleresHorarioFin" text,
    "talleresDiasDisponibles" jsonb,
    es_taller boolean DEFAULT false NOT NULL,
    tiene_escatolina boolean DEFAULT false NOT NULL,
    capacidad_simultanea integer,
    requiere_aprobacion_citas boolean DEFAULT true NOT NULL,
    taller_direccion_id uuid,
    default_aereo boolean DEFAULT false NOT NULL
);


ALTER TABLE public.prestatario OWNER TO tmsdb;

--
-- Name: prestatarios; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.prestatarios (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT '2025-08-11 07:20:07.948'::timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT '2025-08-11 07:20:07.948'::timestamp without time zone NOT NULL,
    _deleted_at timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    "tipoCarga" public.prestatarios_tipocarga_enum,
    contenedor public.prestatarios_contenedor_enum,
    transportes jsonb,
    ayudantes jsonb,
    "cargasEspeciales" jsonb,
    rating double precision,
    licencia jsonb,
    "maxWeight" numeric,
    "maxVolume" numeric,
    user_id uuid
);


ALTER TABLE public.prestatarios OWNER TO tmsdb;

--
-- Name: prestatarioserv; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.prestatarioserv (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.502'::timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.503'::timestamp without time zone NOT NULL,
    _deleted_at timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    name character varying,
    description character varying,
    descripcion text,
    prestatario_id uuid NOT NULL,
    servicio_id uuid NOT NULL,
    precio numeric(10,2) NOT NULL
);


ALTER TABLE public.prestatarioserv OWNER TO tmsdb;

--
-- Name: proposal; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.proposal (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    message text,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "cargaId" uuid,
    "prestatarioId" uuid NOT NULL,
    "proposerId" uuid,
    carta_generated boolean DEFAULT false NOT NULL,
    "assignedVehicle" json,
    "peticionId" uuid
);


ALTER TABLE public.proposal OWNER TO tmsdb;

--
-- Name: proposals_alquiler; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.proposals_alquiler (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    status character varying(40) DEFAULT 'pending'::character varying NOT NULL,
    message text,
    carta_generated boolean DEFAULT false NOT NULL,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL,
    "solicitudId" uuid,
    "prestatarioId" uuid,
    "proposerId" uuid
);


ALTER TABLE public.proposals_alquiler OWNER TO tmsdb;

--
-- Name: proposals_services; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.proposals_services (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    status character varying(40) DEFAULT 'pending'::character varying NOT NULL,
    "serviceType" character varying(50),
    message text,
    carta_generated boolean DEFAULT false NOT NULL,
    "createdAt" timestamp with time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT now() NOT NULL,
    solicitud_id uuid,
    prestatario_id uuid NOT NULL,
    proposer_id uuid NOT NULL
);


ALTER TABLE public.proposals_services OWNER TO tmsdb;

--
-- Name: proveedores; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.proveedores (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.502'::timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.503'::timestamp without time zone NOT NULL,
    _deleted_at timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    name character varying,
    description character varying,
    "isUsed" boolean DEFAULT false NOT NULL,
    email character varying NOT NULL,
    phone character varying NOT NULL,
    direccion json NOT NULL
);


ALTER TABLE public.proveedores OWNER TO tmsdb;

--
-- Name: province; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.province (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.502'::timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.503'::timestamp without time zone NOT NULL,
    _deleted_at timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    name character varying,
    description character varying,
    "isUsed" boolean DEFAULT false NOT NULL,
    country_id uuid
);


ALTER TABLE public.province OWNER TO tmsdb;

--
-- Name: reserva; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.reserva (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.502'::timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.503'::timestamp without time zone NOT NULL,
    _deleted_at timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    name character varying,
    description character varying,
    apellido character varying NOT NULL,
    correo character varying NOT NULL,
    fecha character varying NOT NULL,
    hora character varying NOT NULL,
    direccion character varying NOT NULL,
    state public.reserva_state_enum DEFAULT 'Ordenado'::public.reserva_state_enum NOT NULL,
    vin character varying,
    motor character varying,
    bl character varying,
    contenedor character varying,
    "nombreSolicitante" character varying,
    "correoSolicitante" character varying,
    "telefonoSolicitante" character varying,
    "fechaSolicitud" character varying,
    comentarios character varying,
    "comercialId" uuid,
    "servicioId" uuid,
    "userId" uuid NOT NULL
);


ALTER TABLE public.reserva OWNER TO tmsdb;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.roles (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.502'::timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.503'::timestamp without time zone NOT NULL,
    _deleted_at timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    name character varying,
    description character varying
);


ALTER TABLE public.roles OWNER TO tmsdb;

--
-- Name: servicio; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.servicio (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.502'::timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.503'::timestamp without time zone NOT NULL,
    _deleted_at timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    name character varying,
    description character varying,
    prestatario boolean NOT NULL
);


ALTER TABLE public.servicio OWNER TO tmsdb;

--
-- Name: setting; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.setting (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.502'::timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.503'::timestamp without time zone NOT NULL,
    _deleted_at timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    key character varying(200) NOT NULL,
    value text,
    type character varying(20)
);


ALTER TABLE public.setting OWNER TO tmsdb;

--
-- Name: solicitudes; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.solicitudes (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    solicitante character varying(200) NOT NULL,
    telefono character varying(50) NOT NULL,
    email character varying(200) NOT NULL,
    empresa character varying(200),
    metros_requeridos double precision DEFAULT '0'::double precision,
    altura_m double precision,
    fecha_inicio date,
    duracion character varying(50),
    acceso_horario character varying(50),
    control_temperatura character varying(80),
    servicios text,
    frecuencia character varying(50),
    clasificacion_mercancia character varying(120),
    comentarios text,
    cliente_id uuid,
    assigned_prestatario_id uuid,
    status character varying(30) DEFAULT 'pending'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    fecha_fin date,
    habitaciones_requeridas integer,
    personas integer,
    device_count integer,
    plan character varying(80),
    vehiculo_marca character varying(120),
    vehiculo_placa character varying(80),
    service_requested character varying(80),
    created_by_prestatario_id uuid,
    tipo_uso jsonb,
    seguro_adquirido boolean DEFAULT false NOT NULL,
    valor_factura numeric(15,2),
    tipo_carga_seguro character varying(50),
    factura_url text,
    costo_seguro numeric(15,2)
);


ALTER TABLE public.solicitudes OWNER TO tmsdb;

--
-- Name: taller_horario; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.taller_horario (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.502'::timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.503'::timestamp without time zone NOT NULL,
    _deleted_at timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    dia_semana integer DEFAULT 0 NOT NULL,
    hora_inicio time without time zone NOT NULL,
    hora_fin time without time zone NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    prestatario_id uuid
);


ALTER TABLE public.taller_horario OWNER TO tmsdb;

--
-- Name: taller_servicio; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.taller_servicio (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.502'::timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.503'::timestamp without time zone NOT NULL,
    _deleted_at timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    nombre_personalizado character varying(100) NOT NULL,
    tipo_servicio character varying(100),
    precio_base numeric(10,2) NOT NULL,
    tiempo_estimado_minutos integer DEFAULT 60 NOT NULL,
    activo boolean DEFAULT true NOT NULL,
    prestatario_id uuid
);


ALTER TABLE public.taller_servicio OWNER TO tmsdb;

--
-- Name: tipo_servicio_mecanico; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.tipo_servicio_mecanico (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.502'::timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.503'::timestamp without time zone NOT NULL,
    _deleted_at timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    codigo character varying(50) NOT NULL,
    nombre character varying(100) NOT NULL,
    descripcion character varying(500),
    tiempo_estimado_minutos numeric(10,2),
    activo boolean DEFAULT true NOT NULL
);


ALTER TABLE public.tipo_servicio_mecanico OWNER TO tmsdb;

--
-- Name: tipocarga; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.tipocarga (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.502'::timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.503'::timestamp without time zone NOT NULL,
    _deleted_at timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    name character varying,
    description character varying,
    descripcion character varying
);


ALTER TABLE public.tipocarga OWNER TO tmsdb;

--
-- Name: tipomercado; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.tipomercado (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.502'::timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.503'::timestamp without time zone NOT NULL,
    _deleted_at timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    name character varying,
    description character varying
);


ALTER TABLE public.tipomercado OWNER TO tmsdb;

--
-- Name: tipopago; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.tipopago (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.502'::timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.503'::timestamp without time zone NOT NULL,
    _deleted_at timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    name character varying,
    description character varying
);


ALTER TABLE public.tipopago OWNER TO tmsdb;

--
-- Name: tipos_um; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.tipos_um (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.502'::timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.503'::timestamp without time zone NOT NULL,
    _deleted_at timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    name character varying,
    description character varying,
    "isUsed" boolean DEFAULT false NOT NULL
);


ALTER TABLE public.tipos_um OWNER TO tmsdb;

--
-- Name: tipotransporte; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.tipotransporte (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.502'::timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.503'::timestamp without time zone NOT NULL,
    _deleted_at timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    name character varying,
    description character varying
);


ALTER TABLE public.tipotransporte OWNER TO tmsdb;

--
-- Name: tipoviaje; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.tipoviaje (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.502'::timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.503'::timestamp without time zone NOT NULL,
    _deleted_at timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    name character varying,
    description character varying
);


ALTER TABLE public.tipoviaje OWNER TO tmsdb;

--
-- Name: traza; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.traza (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    ip character varying NOT NULL,
    url character varying NOT NULL,
    "nombreControlador" character varying,
    traza json NOT NULL
);


ALTER TABLE public.traza OWNER TO tmsdb;

--
-- Name: um; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.um (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.502'::timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.503'::timestamp without time zone NOT NULL,
    _deleted_at timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    name character varying,
    description character varying,
    "isUsed" boolean DEFAULT false NOT NULL,
    "tipoUmId" uuid
);


ALTER TABLE public.um OWNER TO tmsdb;

--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.user_roles (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.502'::timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.503'::timestamp without time zone NOT NULL,
    _deleted_at timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    "roleId" uuid,
    "userId" uuid
);


ALTER TABLE public.user_roles OWNER TO tmsdb;

--
-- Name: users; Type: TABLE; Schema: public; Owner: tmsdb
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.502'::timestamp without time zone NOT NULL,
    "createdAt" timestamp without time zone DEFAULT '2026-08-09 20:19:59.503'::timestamp without time zone NOT NULL,
    _deleted_at timestamp without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    name character varying,
    hash character varying,
    email character varying,
    description character varying,
    username character varying,
    lastname character varying,
    phone character varying,
    photo character varying,
    "isLogged" boolean DEFAULT false,
    comercial_code integer,
    role uuid
);


ALTER TABLE public.users OWNER TO tmsdb;

--
-- Data for Name: address_details; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.address_details (id, "updatedAt", "createdAt", _deleted_at, "isActive", name, description, "isUsed", "homeNumber", "streetName", address, "postalCode", municipality_id) FROM stdin;
\.


--
-- Data for Name: calendar; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.calendar (id, "updatedAt", "createdAt", _deleted_at, "isActive", name, description, fecha, inicio, fin, "fullDay", "user", state, "isService") FROM stdin;
d835e77f-d248-4e85-b146-8d8714cb311e	2025-08-08 01:58:30.915098	2025-08-08 05:39:04.439	\N	f	\N	\N	2025-08-11 02:00:00	9	10	f	a166a848-74e4-42b9-a002-61aa9699b9fc	Disponible	f
4022de8a-2375-4cc3-8a94-86ad006a13b6	2025-08-08 01:58:33.270397	2025-08-08 05:39:04.439	\N	f	\N	\N	2025-08-12 09:00:00	9	10	f	a166a848-74e4-42b9-a002-61aa9699b9fc	No Disponible	f
\.


--
-- Data for Name: carga; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.carga (id, "updatedAt", "createdAt", _deleted_at, "isActive", name, description, order_id, carga_serie, remitente_dni, remitente_nombre, direccion, emisor_dni, emisor_nombre, emisor_direccion, cant_bultos, peso_total, vol_bulto, origen_string, destino_string, autorizado_recoger, tipo_carga, precio, tarifabase, volumen, impuesto, comision, origen, destino, cliente_id, estado, via, status_reason, status_date, pod_dni_front_base64, pod_dni_back_base64, pod_signed, pod_signature_confirmed, assigned_prestatario_id, "fechaRegistro", fecha_emision, no_orden, comprador_interno, autorizado_lugar, fecha_autorizada, representante_nombre, representante_carnet, representante_cargo, firma, tipo_producto, contenedor_siglas, nombre_destinatario, nombre_buque, mfto_no, bl_no, dm_no, vehiculo_pertenece_a, conducido_por, chapa_no, lot_no, hoja_ruta_no, carta_porte_no, chapa_tractivo_no, remolque_no, conductor_carnet_no, licencia_conduccion_no, basificado_en) FROM stdin;
89c2ebff-4e93-4f0c-9c03-e60a823dae87	2025-12-18 10:53:31.046051	2025-09-11 05:12:03.319	\N	t	\N	\N	ORD1757568797396	\N	97848456543	Remitente Test 3	Direccion Test 5	93739372930	Ariel Morales Gomez	Direccion Test 1	16	378	90	Habana	La Isla	Nanda Morales Gomez	Carga general	154257	26460	1440	2911	7346	\N	\N	8ec4289e-b10e-40b4-b9dc-db53606cd12e	asignado	aerea	\N	\N	\N	\N	f	f	cddafff0-8e7e-49a5-b89a-8e29e693eeb2	2025-09-18 01:21:45.465948-04	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
53952cbe-7388-4e6b-9c80-3cd118558c10	2026-02-06 12:55:47.362166	2026-01-18 22:10:04.622	\N	t	\N	\N	ORD1770400119512	\N	990326080478	gomez	29b entre 70 y 72	555558	drydryt	y7iytiyuui	1	100	100	Habana	La Isla	erter	Carga general	11309	7000	100	770	539	\N	\N	8642995f-7b3a-493c-9fc7-8963db3845e4	asignado	terrestre	\N	\N	\N	\N	f	f	cddafff0-8e7e-49a5-b89a-8e29e693eeb2	2026-02-06 12:48:40.051591-05	2026-02-05 19:00:00-05		Raonel	dstgdrt	2026-02-05 19:00:00-05			55	etertet	cajas	555555	edte5t															
e2d97a60-5c46-407e-a625-d08a9262a868	2025-09-24 10:49:16.043364	2025-09-11 05:12:03.319	\N	t	\N	\N	ORD1757568718270	\N	97848456543	Remitente Test 2	Direccion Test 3	92828372236	Ariel Morales Gomez	Direccion Test 4	9	500	22	Habana	La Isla	Nanda Morales Gomez	Refrigerado	40793	35000	198	3850	1943	\N	\N	8ec4289e-b10e-40b4-b9dc-db53606cd12e	listo_para_recoger	terrestre	\N	\N	\N	\N	f	f	681e455f-b63a-4381-8126-3caf9ca968f4	2025-09-18 01:21:45.465948-04	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
bb7381d7-c46f-4ce5-a364-edb66314da06	2026-03-04 05:56:26.339	2026-03-04 05:56:26.339	\N	t	\N	\N	ORD1772919262802	\N	83093000105	Amel Fonte	Calle 76 Nro. 2707 entre 27 y 29 playa	83093000105	Amel Fonte	\N	1920	25000	30	Habana	Habana	Juan Juan	Seco	6250125	1750000	57600	192500	297625	\N	\N	8f1bf5a7-2b13-4764-b7a8-1f76730bcfb4	propuestas_pendientes	terrestre	\N	\N	\N	\N	f	f	\N	2026-03-07 16:34:22.902687-05	2026-03-06 19:00:00-05			Villanueva	2026-03-06 19:00:00-05			Comercial		Arroz	CFUA 265569	Pepe Pepe															
de69bd35-3fdd-463d-a19c-55864d809aae	2026-05-14 20:36:37.58446	2025-09-11 05:12:03.319	\N	t	\N	\N	ORD1757568598901	\N	97110607363	Remitente Test 1	Direccion Test 1	93827262523	Ariel Morales Gomez	Direccion Test 2	6	100	100	santiago	Habana	Nanda Morales Gomez	Carga general	63809	7000	600	770	3039	\N	\N	8ec4289e-b10e-40b4-b9dc-db53606cd12e	recogido	terrestre	\N	\N	\N	\N	f	f	df137d33-e5d7-44d3-b796-d8d720d9fc38	2025-09-18 01:21:45.465948-04	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
00d3fb6a-b319-421d-ac5b-44c8f0d70e14	2026-07-20 23:48:33.832	2026-07-20 23:48:33.832	\N	t	\N	\N	ORD1785009779499	\N	83093000105	Amel Fonte	CALLE 76MRO.2707 ENTRE 27 Y 29 PLAYA	83093000105	Pepe company	SANTIAGO AEROPUERTO	5	1200	16	Habana	La Isla	PEPE COMPANY	Carga general	97902	84000	80	9240	4662	\N	\N	8f1bf5a7-2b13-4764-b7a8-1f76730bcfb4	propuestas_pendientes	aerea	\N	\N	\N	\N	f	f	\N	2026-07-25 16:03:00.132196-04	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
6f1d37fe-e17c-4ef5-bdf2-9f1f15008118	2026-08-09 20:19:59.502	2026-08-09 20:19:59.503	\N	t	\N	\N	ORD1786364269180	\N	83093000105	Amel Fonte	calle 76 nro.2707 entre 27 y 29 playa	83093000105	Pepe company	kjsdlkjalk	1	1200	10	Habana	La Isla	Juan Juan	Seco	97902	84000	10	9240	4662	\N	\N	8f1bf5a7-2b13-4764-b7a8-1f76730bcfb4	propuestas_pendientes	aerea	\N	\N	\N	\N	f	f	\N	2026-08-10 08:17:49.313057-04	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
7f3394c8-b223-42f4-b6b9-e7a7f4b75991	2026-08-09 20:19:59.502	2026-08-09 20:19:59.503	\N	t	\N	\N	ORD1786364442325	\N	83093000105	Amel Fonte	calle 76 1231 / msflksjfklj y jskljaslk	83093000105	Amel Fonte	zdah 75 nasjf jfklaklmcal	1	1000	5	Habana	Habana	Juan Juan	Seco	81585	70000	5	7700	3885	\N	\N	8f1bf5a7-2b13-4764-b7a8-1f76730bcfb4	propuestas_pendientes	aerea	\N	\N	\N	\N	f	f	\N	2026-08-10 08:20:42.443248-04	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
5e4f3ecc-f226-4932-a651-cd376e58f6ee	2026-08-09 20:19:59.502	2026-08-09 20:19:59.503	\N	t	\N	\N	ORD1786399416239	\N	123123	Luis Alberto Vidal Mesa	Fontanar calle 2	2312313	Ariel AA	Fontanar calle 2	22	22	22	Habana	Habana	Luis Vidal	Seco	50997	1540	484	169	2428	\N	\N	8ec4289e-b10e-40b4-b9dc-db53606cd12e	propuestas_pendientes	aerea	\N	\N	\N	\N	f	f	\N	2026-08-10 18:03:36.589826-04	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
61d6cb6d-72e3-4ce4-9db3-5f62787e29bb	2026-08-11 07:40:03.519518	2026-08-09 20:19:59.503	\N	t	\N	\N	ORD1786364251524	\N	83093000105	Amel Fonte	calle 76 nro.2707 entre 27 y 29 playa	83093000105	Pepe company	kjsdlkjalk	1	1200	10	Habana	La Isla	Juan Juan	Seco	97902	84000	10	9240	4662	\N	\N	8f1bf5a7-2b13-4764-b7a8-1f76730bcfb4	propuestas_pendientes	aerea	\N	\N	\N	\N	f	f	\N	2026-08-10 08:17:31.677137-04	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
94c41559-2f93-488d-afb9-9077d78d287e	2026-08-09 20:19:59.502	2026-08-09 20:19:59.503	\N	t	\N	\N	ORD1786456905956	\N	888	Mimismo	mio casa $23	222	Otro yo	su casa %3	1	6	2	Habana	La Isla	primo yo	Carga general	489	420	2	46	23	\N	\N	8ec4289e-b10e-40b4-b9dc-db53606cd12e	propuestas_pendientes	aerea	\N	\N	\N	\N	f	f	\N	2026-08-11 10:01:32.271739-04	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: cita_taller; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.cita_taller (id, "updatedAt", "createdAt", _deleted_at, "isActive", fecha_hora_inicio, fecha_hora_fin, estado, es_servicio_escatolina, peso_kg, volumen_m3, fecha_estimada_viaje, licencia_operativa, precio_servicio_base, precio_flete_escatolina, precio_total, fecha_solicitud, fecha_respuesta_taller, motivo_rechazo, notas_adicionales, taller_id, cliente_id, servicio_id, origen_id, destino_id, tipo_carga_id, tipo_transporte_id) FROM stdin;
\.


--
-- Data for Name: cliente; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.cliente (id, "updatedAt", "createdAt", _deleted_at, "isActive", company, contact_name, contact_phone, tax_id, address, user_id, modalidad) FROM stdin;
8642995f-7b3a-493c-9fc7-8963db3845e4	2025-08-12 05:23:53.184	2025-08-12 05:23:53.184	\N	t	Desoft	Dariel Lazo Tamayo	+5355651998	978898034	Gelabert	db1ed43d-aba6-47e7-a83b-f57b5f38c6c4	\N
8ec4289e-b10e-40b4-b9dc-db53606cd12e	2025-09-03 02:14:18.900921	2025-08-14 04:32:08.207	\N	t	Acubamos	Pedro Perez Perez	+5357585958	97503928176	Lisa Marianao	4b097939-a723-44d6-ad1c-2b069dd5f8c4	\N
cc37f411-f850-42df-a39e-03d0b983b94d	2025-10-20 05:26:21.335	2025-10-20 05:26:21.336	\N	t	\N	\N	\N	\N	\N	48564711-cdba-44b3-a187-24be2578e74a	\N
8f1bf5a7-2b13-4764-b7a8-1f76730bcfb4	2025-10-24 09:12:11.531	2025-10-24 09:12:11.531	\N	t	KIA	Julio	+5358595059	9857564643	Bejucal 92883	45f28bf4-2268-4f7e-93ba-1f9176f62bfe	terrestre
5d78110e-fdf9-4dd1-aca1-ad2428284fb9	2025-10-30 04:33:50.146	2025-10-30 04:33:50.146	\N	t	gcomcargo	clientegcom	+5351234567		calle 2 esq 5tq	5eb51ff5-1f8f-403f-9857-3611c76249f0	terrestre
\.


--
-- Data for Name: comercial; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.comercial (id, "updatedAt", "createdAt", _deleted_at, "isActive", name, description, apellido, correo, telefono) FROM stdin;
\.


--
-- Data for Name: configuracion; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.configuracion (id, "updatedAt", "createdAt", _deleted_at, "isActive", "from", "to", "porcientoConfReserva", "porcientoMinPrice", impuesto) FROM stdin;
\.


--
-- Data for Name: country; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.country (id, "updatedAt", "createdAt", _deleted_at, "isActive", name, description, "isUsed", code, "numericCode") FROM stdin;
\.


--
-- Data for Name: cuenta_bancaria; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.cuenta_bancaria (id, "updatedAt", "createdAt", _deleted_at, "isActive", beneficiario, "direccionBeneficiario", "nombreBanco", "direccionBanco", codigo, currency, "numeroCuenta") FROM stdin;
\.


--
-- Data for Name: customer; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.customer (id, "updatedAt", "createdAt", _deleted_at, "isActive", name, description, email, "addessLineOne", "addessLineTwo", "cityTown", "postalCode", planes_id) FROM stdin;
\.


--
-- Data for Name: customer_cuenta; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.customer_cuenta (id, "updatedAt", "createdAt", _deleted_at, "isActive", name, description, customer_id, cuenta_bancaria_id) FROM stdin;
\.


--
-- Data for Name: destino; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.destino (id, "updatedAt", "createdAt", _deleted_at, "isActive", name, description) FROM stdin;
138ef1cf-12c1-4164-b68b-882a486569e0	2026-01-18 22:10:04.622	2026-01-18 22:10:04.622	\N	t	Habana	Viajes Habana
7c3aaf35-858f-4c89-a274-c4bbc4496031	2026-01-29 15:19:24.583553	2026-01-18 22:10:04.622	2026-01-29 15:19:24.583553	t	Matanzas	Refresco
8e82bba5-76a9-4b15-b91a-c8cc2c16b427	2026-02-19 01:09:56.238745	2025-07-26 19:28:12.61	\N	t	La Isla	Isla de la Juventud
\.


--
-- Data for Name: doccarga; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.doccarga (id, "updatedAt", "createdAt", _deleted_at, "isActive", name, description, file, carga) FROM stdin;
\.


--
-- Data for Name: locality; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.locality (id, "updatedAt", "createdAt", _deleted_at, "isActive", name, description, "isUsed", municipality_id) FROM stdin;
\.


--
-- Data for Name: modalidad; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.modalidad (id, "updatedAt", "createdAt", _deleted_at, "isActive", name, description, detalles, caracteristicas) FROM stdin;
\.


--
-- Data for Name: municipality; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.municipality (id, "updatedAt", "createdAt", _deleted_at, "isActive", name, description, "isUsed", province_id) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.notifications (id, "updatedAt", "createdAt", _deleted_at, "isActive", title, read, type, link, meta, user_origin_id, user_target_id, message) FROM stdin;
8510d70b-3122-479f-9aeb-c0c9b5ce95f3	2025-09-11 06:46:20.816	2025-09-11 06:46:20.817	\N	t	Nueva propuesta de carga	f	proposal	/proposals/251c357b-e978-430b-a795-c9859ec40c72	{"cargaId": "de69bd35-3fdd-463d-a19c-55864d809aae", "proposalId": "251c357b-e978-430b-a795-c9859ec40c72"}	b1a62649-8f51-47e9-99d3-3aa080126bf6	49041db6-0a38-4678-a195-5e1ab02222b2	Dariel te ha propuesto la carga ORD1757568598901.
cb98225d-57e0-407e-b3df-74d409484614	2025-09-11 06:46:20.816	2025-09-11 06:46:20.817	\N	t	Nueva propuesta de carga	f	proposal	/proposals/ede79ccf-4df4-455d-9003-94ed8a4b0e2e	{"cargaId": "e2d97a60-5c46-407e-a625-d08a9262a868", "proposalId": "ede79ccf-4df4-455d-9003-94ed8a4b0e2e"}	b1a62649-8f51-47e9-99d3-3aa080126bf6	1cecc249-b59e-4c68-9b87-85a2e98dd8ee	Dariel te ha propuesto la carga ORD1757568718270.
c84a1a04-8ac1-4d70-871f-a988225e9ce4	2025-09-11 06:46:20.816	2025-09-11 06:46:20.817	\N	t	Nueva propuesta de carga	f	proposal	/proposals/a82a5faa-62e7-430d-bf2b-18d321fc2c77	{"cargaId": "4dd36563-f1ee-47f5-8ebf-ad8cdd9efa2a", "proposalId": "a82a5faa-62e7-430d-bf2b-18d321fc2c77"}	b1a62649-8f51-47e9-99d3-3aa080126bf6	49041db6-0a38-4678-a195-5e1ab02222b2	Dariel te ha propuesto la carga ORD1757640496858.
54fcecb8-d78f-46fb-b3ab-78aa60fe3a30	2025-09-11 06:46:20.816	2025-09-11 06:46:20.817	\N	t	Nueva propuesta de carga	f	proposal	/proposals/ee9a644d-2fab-408d-b756-24aae858177c	{"cargaId": "4dd36563-f1ee-47f5-8ebf-ad8cdd9efa2a", "proposalId": "ee9a644d-2fab-408d-b756-24aae858177c"}	b1a62649-8f51-47e9-99d3-3aa080126bf6	82a806d2-2f4f-4857-8460-d762da2e694b	Dariel te ha propuesto la carga ORD1757640496858.
170c4b4c-9f8f-4311-8a8e-218cad689fc3	2025-09-11 06:46:20.816	2025-09-11 06:46:20.817	\N	t	Nueva propuesta de carga	f	proposal	/proposals/a7c9ad2d-e6b4-4f6d-8617-118f913a35d3	{"cargaId": "de69bd35-3fdd-463d-a19c-55864d809aae", "proposalId": "a7c9ad2d-e6b4-4f6d-8617-118f913a35d3"}	b1a62649-8f51-47e9-99d3-3aa080126bf6	82a806d2-2f4f-4857-8460-d762da2e694b	Dariel te ha propuesto la carga ORD1757568598901.
3c4596a9-2612-437f-971f-df891dac7b88	2025-09-18 06:40:38.417	2025-09-18 06:40:38.417	\N	t	Nueva propuesta de carga	f	proposal	/proposals/829ddba9-9b21-40a9-b28e-86a4b63e8e9c	{"cargaId": "c2dc26ea-ef83-4320-8626-7ca8e1610e72", "proposalId": "829ddba9-9b21-40a9-b28e-86a4b63e8e9c"}	b1a62649-8f51-47e9-99d3-3aa080126bf6	698b5a78-92db-4076-8e28-55f5c6e27f69	Dariel te ha propuesto la carga ORD1758222202931.
4a5dbe38-d4bb-4156-b8e0-0be62ae8033d	2025-09-21 06:51:09.642	2025-09-21 06:51:09.642	\N	t	Propuesta aceptada	f	proposal_accepted	/app/proposals/251c357b-e978-430b-a795-c9859ec40c72	{"action": "confirm_assignment", "cargaId": "de69bd35-3fdd-463d-a19c-55864d809aae", "proposalId": "251c357b-e978-430b-a795-c9859ec40c72"}	49041db6-0a38-4678-a195-5e1ab02222b2	b1a62649-8f51-47e9-99d3-3aa080126bf6	Amel Acubamos Test ha aceptado la propuesta para la carga ORD1757568598901. Confirma para asignar.
e484b9f6-2833-4c08-99ab-469f081786b8	2025-09-21 07:19:50.802	2025-09-21 07:19:50.802	\N	t	Propuesta rechazada	f	proposal_rejected	/app/proposals/02a6d09f-67ab-4200-b779-f5ed02102b19	{"action": "info", "cargaId": "de69bd35-3fdd-463d-a19c-55864d809aae", "proposalId": "02a6d09f-67ab-4200-b779-f5ed02102b19"}	49041db6-0a38-4678-a195-5e1ab02222b2	4b097939-a723-44d6-ad1c-2b069dd5f8c4	Amel Acubamos Test ha rechazado la propuesta para la carga ORD1757568598901.
b2059b03-9eb3-4633-9709-b61d3261a590	2025-09-21 07:19:50.802	2025-09-21 07:19:50.802	\N	t	Nueva propuesta de carga	f	proposal	/proposals/730f2b92-7774-4f8c-8a48-0d3bd050727c	{"cargaId": "89c2ebff-4e93-4f0c-9c03-e60a823dae87", "proposalId": "730f2b92-7774-4f8c-8a48-0d3bd050727c"}	4b097939-a723-44d6-ad1c-2b069dd5f8c4	698b5a78-92db-4076-8e28-55f5c6e27f69	Ariel te ha propuesto la carga ORD1757568797396.
1072498e-f1bd-445b-8bab-9f01cd9c0868	2025-09-21 07:19:50.802	2025-09-21 07:19:50.802	\N	t	Propuesta aceptada	f	proposal_accepted	/app/proposals/a7c9ad2d-e6b4-4f6d-8617-118f913a35d3	{"action": "confirm_assignment", "cargaId": "de69bd35-3fdd-463d-a19c-55864d809aae", "proposalId": "a7c9ad2d-e6b4-4f6d-8617-118f913a35d3"}	82a806d2-2f4f-4857-8460-d762da2e694b	b1a62649-8f51-47e9-99d3-3aa080126bf6	Agencia Nova Nova Cuba ha aceptado la propuesta para la carga ORD1757568598901. Confirma para asignar.
d8a2792e-f37f-442a-b0e8-5b72325537f2	2025-09-21 23:10:00.168383	2025-09-21 07:19:50.802	\N	t	Propuesta aceptada	t	proposal_accepted	/app/proposals/75230170-412c-447e-8988-cb002f7c53b3	{"action": "confirm_assignment", "cargaId": "de69bd35-3fdd-463d-a19c-55864d809aae", "confirmed": true, "proposalId": "75230170-412c-447e-8988-cb002f7c53b3"}	49041db6-0a38-4678-a195-5e1ab02222b2	4b097939-a723-44d6-ad1c-2b069dd5f8c4	Amel Acubamos Test ha aceptado la propuesta para la carga ORD1757568598901. Confirma para asignar.
bf8c4c33-a5f7-4cba-8351-26c2eafdcad7	2025-09-21 07:19:50.802	2025-09-21 07:19:50.802	\N	t	Cambio de estado de tu carga	f	CARGA_STATUS	/app/cargas/de69bd35-3fdd-463d-a19c-55864d809aae	{"estado": "listo_para_recoger", "cargaId": "de69bd35-3fdd-463d-a19c-55864d809aae"}	49041db6-0a38-4678-a195-5e1ab02222b2	4b097939-a723-44d6-ad1c-2b069dd5f8c4	La carga ORD1757568598901 cambió a estado: listo_para_recoger.
ae4eb1c6-d25a-4efd-98a1-a2d0ad4ecb1f	2025-09-21 07:19:50.802	2025-09-21 07:19:50.802	\N	t	Cambio de estado de tu carga	f	CARGA_STATUS	/app/cargas/de69bd35-3fdd-463d-a19c-55864d809aae	{"estado": "recogido", "cargaId": "de69bd35-3fdd-463d-a19c-55864d809aae"}	49041db6-0a38-4678-a195-5e1ab02222b2	4b097939-a723-44d6-ad1c-2b069dd5f8c4	La carga ORD1757568598901 cambió a estado: recogido.
8745dddb-658a-4714-95bc-8d3b10bee6bc	2025-09-21 07:19:50.802	2025-09-21 07:19:50.802	\N	t	Cambio de estado de tu carga	f	CARGA_STATUS	/app/cargas/de69bd35-3fdd-463d-a19c-55864d809aae	{"estado": "en_transito", "cargaId": "de69bd35-3fdd-463d-a19c-55864d809aae"}	49041db6-0a38-4678-a195-5e1ab02222b2	4b097939-a723-44d6-ad1c-2b069dd5f8c4	La carga ORD1757568598901 cambió a estado: en_transito.
3169142c-408d-42c0-8788-0a943bbc0240	2025-09-21 07:19:50.802	2025-09-21 07:19:50.802	\N	t	Cambio de estado de tu carga	f	CARGA_STATUS	/app/cargas/de69bd35-3fdd-463d-a19c-55864d809aae	{"estado": "llegado_al_destino", "cargaId": "de69bd35-3fdd-463d-a19c-55864d809aae"}	49041db6-0a38-4678-a195-5e1ab02222b2	4b097939-a723-44d6-ad1c-2b069dd5f8c4	La carga ORD1757568598901 cambió a estado: llegado_al_destino.
6612ce92-5376-4c57-a8e2-cd7e84993561	2025-09-21 07:19:50.802	2025-09-21 07:19:50.802	\N	t	Cambio de estado de tu carga	f	CARGA_STATUS	/app/cargas/de69bd35-3fdd-463d-a19c-55864d809aae	{"estado": "en_reparto_final", "cargaId": "de69bd35-3fdd-463d-a19c-55864d809aae"}	49041db6-0a38-4678-a195-5e1ab02222b2	4b097939-a723-44d6-ad1c-2b069dd5f8c4	La carga ORD1757568598901 cambió a estado: en_reparto_final.
53371f01-c63a-44d4-bfa7-fe51727d729b	2025-09-21 07:19:50.802	2025-09-21 07:19:50.802	\N	t	Carga entregada	f	CARGA_DELIVERED	/app/cargas/de69bd35-3fdd-463d-a19c-55864d809aae	{"estado": "entregado", "cargaId": "de69bd35-3fdd-463d-a19c-55864d809aae"}	49041db6-0a38-4678-a195-5e1ab02222b2	4b097939-a723-44d6-ad1c-2b069dd5f8c4	La carga ORD1757568598901 ha sido entregada. Revisa comprobantes.
cd5b977b-f977-4a1b-875a-40cafd7c3953	2026-03-13 15:37:06.32457	2025-09-21 07:19:50.802	\N	t	Asignación confirmada	f	proposal_confirmed	/app/cargas/de69bd35-3fdd-463d-a19c-55864d809aae	{"cargaId": "de69bd35-3fdd-463d-a19c-55864d809aae", "proposalId": "75230170-412c-447e-8988-cb002f7c53b3"}	4b097939-a723-44d6-ad1c-2b069dd5f8c4	49041db6-0a38-4678-a195-5e1ab02222b2	El cliente confirmó la asignación de la carga ORD1757568598901. Procede con la gestión.
484c270e-6377-4fd4-84da-cbed507fec85	2026-03-13 15:47:56.711034	2025-09-21 07:19:50.802	\N	t	Nueva propuesta de carga	f	proposal	/proposals/75230170-412c-447e-8988-cb002f7c53b3	{"cargaId": "de69bd35-3fdd-463d-a19c-55864d809aae", "proposalId": "75230170-412c-447e-8988-cb002f7c53b3"}	4b097939-a723-44d6-ad1c-2b069dd5f8c4	49041db6-0a38-4678-a195-5e1ab02222b2	Ariel te ha propuesto la carga ORD1757568598901.
5582cabe-abc4-4ec4-9a40-ae139af305d7	2026-03-13 15:39:43.937874	2025-09-21 07:19:50.802	\N	t	Nueva propuesta de carga	t	proposal	/proposals/d232415d-a3f1-4d1d-8b5c-612353de3825	{"cargaId": "3eeaea11-59f9-436a-aebf-af812f6efc16", "proposalId": "d232415d-a3f1-4d1d-8b5c-612353de3825"}	b1a62649-8f51-47e9-99d3-3aa080126bf6	49041db6-0a38-4678-a195-5e1ab02222b2	Dariel te ha propuesto la carga ORD1757569370567.
3efd09ff-8382-41dd-8c63-d1dbcaac8c8a	2025-09-21 07:19:50.802	2025-09-21 07:19:50.802	\N	t	Propuesta aceptada	f	proposal_accepted	/app/proposals/730f2b92-7774-4f8c-8a48-0d3bd050727c	{"action": "confirm_assignment", "cargaId": "89c2ebff-4e93-4f0c-9c03-e60a823dae87", "proposalId": "730f2b92-7774-4f8c-8a48-0d3bd050727c"}	698b5a78-92db-4076-8e28-55f5c6e27f69	4b097939-a723-44d6-ad1c-2b069dd5f8c4	Mypime F&F Fast and Furious ha aceptado la propuesta para la carga ORD1757568797396. Confirma para asignar.
0578393d-979b-45f8-9f81-95087527a209	2025-09-21 07:19:50.802	2025-09-21 07:19:50.802	\N	t	Propuesta rechazada	f	proposal_rejected	/app/proposals/829ddba9-9b21-40a9-b28e-86a4b63e8e9c	{"action": "info", "cargaId": "c2dc26ea-ef83-4320-8626-7ca8e1610e72", "proposalId": "829ddba9-9b21-40a9-b28e-86a4b63e8e9c"}	698b5a78-92db-4076-8e28-55f5c6e27f69	b1a62649-8f51-47e9-99d3-3aa080126bf6	Mypime F&F Fast and Furious ha rechazado la propuesta para la carga ORD1758222202931.
5a33c827-1d81-46a2-aa55-5cca0b99f2d5	2025-09-21 07:19:50.802	2025-09-21 07:19:50.802	\N	t	Nueva propuesta de carga	f	proposal	/proposals/2fe45e8c-28ab-4567-a9f2-f3e4dc8ec9e3	{"cargaId": "c2dc26ea-ef83-4320-8626-7ca8e1610e72", "proposalId": "2fe45e8c-28ab-4567-a9f2-f3e4dc8ec9e3"}	4b097939-a723-44d6-ad1c-2b069dd5f8c4	698b5a78-92db-4076-8e28-55f5c6e27f69	Ariel te ha propuesto la carga ORD1758222202931.
d7030874-ab74-4a59-afe0-3adada18f90c	2025-09-21 07:19:50.802	2025-09-21 07:19:50.802	\N	t	Propuesta aceptada	f	proposal_accepted	/app/proposals/2fe45e8c-28ab-4567-a9f2-f3e4dc8ec9e3	{"action": "confirm_assignment", "cargaId": "c2dc26ea-ef83-4320-8626-7ca8e1610e72", "proposalId": "2fe45e8c-28ab-4567-a9f2-f3e4dc8ec9e3"}	698b5a78-92db-4076-8e28-55f5c6e27f69	4b097939-a723-44d6-ad1c-2b069dd5f8c4	Mypime F&F Fast and Furious ha aceptado la propuesta para la carga ORD1758222202931. Confirma para asignar.
36d9edca-1091-4c74-ad26-d9b6e5ab784e	2025-09-21 07:19:50.802	2025-09-21 07:19:50.802	\N	t	Nueva propuesta de carga	f	proposal	/proposals/81af18c2-1754-4df0-8969-3efb97f50405	{"cargaId": "9157da23-4326-4f95-9c56-95d702a3a79f", "proposalId": "81af18c2-1754-4df0-8969-3efb97f50405"}	b1a62649-8f51-47e9-99d3-3aa080126bf6	1cecc249-b59e-4c68-9b87-85a2e98dd8ee	Dariel te ha propuesto la carga ORD1757569258586.
f272f17c-d8a3-49f0-b5c8-4c764c2dfdeb	2025-09-24 04:33:48.197	2025-09-24 04:33:48.197	\N	t	Propuesta rechazada	f	proposal_rejected	/app/proposals/d232415d-a3f1-4d1d-8b5c-612353de3825	{"action": "info", "cargaId": "3eeaea11-59f9-436a-aebf-af812f6efc16", "proposalId": "d232415d-a3f1-4d1d-8b5c-612353de3825"}	49041db6-0a38-4678-a195-5e1ab02222b2	b1a62649-8f51-47e9-99d3-3aa080126bf6	Amel Acubamos Test ha rechazado la propuesta para la carga ORD1757569370567.
dc929da7-c1ab-4776-a5d8-c6b75920bf0e	2025-09-24 06:38:46.804	2025-09-24 06:38:46.804	\N	t	Asignación confirmada	f	proposal_confirmed	/app/cargas/e2d97a60-5c46-407e-a625-d08a9262a868	{"cargaId": "e2d97a60-5c46-407e-a625-d08a9262a868", "proposalId": "216ebc71-f116-41b9-92e3-53cc2488ede6"}	b1a62649-8f51-47e9-99d3-3aa080126bf6	1cecc249-b59e-4c68-9b87-85a2e98dd8ee	El cliente confirmó la asignación de la carga ORD1757568718270. Procede con la gestión.
efb67a2f-2a9c-4fc1-b266-481d09b85cb4	2025-09-24 06:38:46.804	2025-09-24 06:38:46.804	\N	t	Nueva propuesta de carga	f	proposal	/proposals/216ebc71-f116-41b9-92e3-53cc2488ede6	{"cargaId": "e2d97a60-5c46-407e-a625-d08a9262a868", "proposalId": "216ebc71-f116-41b9-92e3-53cc2488ede6"}	b1a62649-8f51-47e9-99d3-3aa080126bf6	1cecc249-b59e-4c68-9b87-85a2e98dd8ee	Dariel te ha propuesto la carga ORD1757568718270.
b4a77af4-66ee-4b13-a2a2-eaf4e89da089	2025-09-24 10:41:51.644791	2025-09-24 06:38:46.804	\N	t	Propuesta aceptada	f	proposal_accepted	/app/proposals/216ebc71-f116-41b9-92e3-53cc2488ede6	{"action": "confirm_assignment", "cargaId": "e2d97a60-5c46-407e-a625-d08a9262a868", "confirmed": true, "proposalId": "216ebc71-f116-41b9-92e3-53cc2488ede6"}	1cecc249-b59e-4c68-9b87-85a2e98dd8ee	b1a62649-8f51-47e9-99d3-3aa080126bf6	Alejandro Acubamos Test ha aceptado la propuesta para la carga ORD1757568718270. Confirma para asignar.
632f52aa-14c1-4e6a-b670-a83a234361fb	2025-09-24 06:38:46.804	2025-09-24 06:38:46.804	\N	t	Nueva propuesta de carga	f	proposal	/proposals/3eb1c3ae-490a-4ceb-b195-39fa2cebf3ea	{"cargaId": "b78d0dda-ba61-443e-a3b5-119ad179cbf8", "proposalId": "3eb1c3ae-490a-4ceb-b195-39fa2cebf3ea"}	db1ed43d-aba6-47e7-a83b-f57b5f38c6c4	1cecc249-b59e-4c68-9b87-85a2e98dd8ee	Hassan te ha propuesto la carga ORD1758725027817.
5db1407d-ea57-42d9-b70b-4630d09007cf	2025-09-24 06:38:46.804	2025-09-24 06:38:46.804	\N	t	Nueva propuesta de carga	f	proposal	/proposals/e19888b4-6f78-441c-a1be-4b5552fc932b	{"cargaId": "b78d0dda-ba61-443e-a3b5-119ad179cbf8", "proposalId": "e19888b4-6f78-441c-a1be-4b5552fc932b"}	db1ed43d-aba6-47e7-a83b-f57b5f38c6c4	1cecc249-b59e-4c68-9b87-85a2e98dd8ee	Hassan te ha propuesto la carga ORD1758725027817.
ce426faf-a343-463f-b307-a7ba8ee4edbb	2025-09-24 06:38:46.804	2025-09-24 06:38:46.804	\N	t	Nueva propuesta de carga	f	proposal	/proposals/7558b1d8-f16e-4993-9d50-31b90e394dae	{"cargaId": "b78d0dda-ba61-443e-a3b5-119ad179cbf8", "proposalId": "7558b1d8-f16e-4993-9d50-31b90e394dae"}	b1a62649-8f51-47e9-99d3-3aa080126bf6	1cecc249-b59e-4c68-9b87-85a2e98dd8ee	Dariel te ha propuesto la carga ORD1758725027817.
18177610-f947-45ab-bc27-e8f4ef6c6872	2025-09-24 06:38:46.804	2025-09-24 06:38:46.804	\N	t	Propuesta aceptada	f	proposal_accepted	/app/proposals/7558b1d8-f16e-4993-9d50-31b90e394dae	{"action": "confirm_assignment", "cargaId": "b78d0dda-ba61-443e-a3b5-119ad179cbf8", "proposalId": "7558b1d8-f16e-4993-9d50-31b90e394dae"}	1cecc249-b59e-4c68-9b87-85a2e98dd8ee	b1a62649-8f51-47e9-99d3-3aa080126bf6	Alejandro Acubamos Test ha aceptado la propuesta para la carga ORD1758725027817. Confirma para asignar.
873b0406-6ab4-428b-a5fb-c727c3a484ab	2025-09-24 06:38:46.804	2025-09-24 06:38:46.804	\N	t	Cambio de estado de tu carga	f	CARGA_STATUS	/app/cargas/e2d97a60-5c46-407e-a625-d08a9262a868	{"estado": "listo_para_recoger", "cargaId": "e2d97a60-5c46-407e-a625-d08a9262a868"}	1cecc249-b59e-4c68-9b87-85a2e98dd8ee	4b097939-a723-44d6-ad1c-2b069dd5f8c4	La carga ORD1757568718270 cambió a estado: listo_para_recoger.
af0fc266-8a5b-447d-b2c9-884eb77972fe	2025-09-24 06:38:46.804	2025-09-24 06:38:46.804	\N	t	Nueva propuesta de carga	f	proposal	/proposals/34c48f0a-f7c2-4624-a7a6-c501c285e0ed	{"cargaId": "89c2ebff-4e93-4f0c-9c03-e60a823dae87", "proposalId": "34c48f0a-f7c2-4624-a7a6-c501c285e0ed"}	b1a62649-8f51-47e9-99d3-3aa080126bf6	698b5a78-92db-4076-8e28-55f5c6e27f69	Dariel te ha propuesto la carga ORD1757568797396.
0cc2ef8b-9154-4ed7-a4e7-633781451a4b	2025-09-24 06:38:46.804	2025-09-24 06:38:46.804	\N	t	Propuesta aceptada	f	proposal_accepted	/app/proposals/34c48f0a-f7c2-4624-a7a6-c501c285e0ed	{"action": "confirm_assignment", "cargaId": "89c2ebff-4e93-4f0c-9c03-e60a823dae87", "proposalId": "34c48f0a-f7c2-4624-a7a6-c501c285e0ed"}	698b5a78-92db-4076-8e28-55f5c6e27f69	b1a62649-8f51-47e9-99d3-3aa080126bf6	Mypime F&F Fast and Furious ha aceptado la propuesta para la carga ORD1757568797396. Confirma para asignar.
14e97006-d569-4b82-b565-7b6c988268b3	2025-09-24 06:38:46.804	2025-09-24 06:38:46.804	\N	t	Nueva propuesta de carga	f	proposal	/proposals/323b116a-c935-45ea-a838-2b02a1d4dd39	{"cargaId": "c47b1db8-984c-4f0f-9bc2-6ea83324b9e9", "proposalId": "323b116a-c935-45ea-a838-2b02a1d4dd39"}	db1ed43d-aba6-47e7-a83b-f57b5f38c6c4	1cecc249-b59e-4c68-9b87-85a2e98dd8ee	Hassan te ha propuesto la carga ORD1758725870896.
63ce8f4f-28a8-4ce0-beb8-e05e6884d693	2025-09-24 06:38:46.804	2025-09-24 06:38:46.804	\N	t	Asignación confirmada	f	proposal_confirmed	/app/cargas/c47b1db8-984c-4f0f-9bc2-6ea83324b9e9	{"cargaId": "c47b1db8-984c-4f0f-9bc2-6ea83324b9e9", "proposalId": "323b116a-c935-45ea-a838-2b02a1d4dd39"}	db1ed43d-aba6-47e7-a83b-f57b5f38c6c4	1cecc249-b59e-4c68-9b87-85a2e98dd8ee	El cliente confirmó la asignación de la carga ORD1758725870896. Procede con la gestión.
e3d3ed35-a644-4783-ab14-da346fd6bbbf	2025-09-24 10:59:12.733975	2025-09-24 06:38:46.804	\N	t	Propuesta aceptada	t	proposal_accepted	/app/proposals/323b116a-c935-45ea-a838-2b02a1d4dd39	{"action": "confirm_assignment", "cargaId": "c47b1db8-984c-4f0f-9bc2-6ea83324b9e9", "confirmed": true, "proposalId": "323b116a-c935-45ea-a838-2b02a1d4dd39"}	1cecc249-b59e-4c68-9b87-85a2e98dd8ee	db1ed43d-aba6-47e7-a83b-f57b5f38c6c4	Alejandro Acubamos Test ha aceptado la propuesta para la carga ORD1758725870896. Confirma para asignar.
7ad854ba-7be3-41dd-bb24-fb305d7141f9	2025-09-24 06:38:46.804	2025-09-24 06:38:46.804	\N	t	Cambio de estado de tu carga	f	CARGA_STATUS	/app/cargas/c47b1db8-984c-4f0f-9bc2-6ea83324b9e9	{"estado": "listo_para_recoger", "cargaId": "c47b1db8-984c-4f0f-9bc2-6ea83324b9e9"}	1cecc249-b59e-4c68-9b87-85a2e98dd8ee	db1ed43d-aba6-47e7-a83b-f57b5f38c6c4	La carga ORD1758725870896 cambió a estado: listo_para_recoger.
3f778069-798c-43dd-b115-f59593924456	2025-09-24 06:38:46.804	2025-09-24 06:38:46.804	\N	t	Cambio de estado de tu carga	f	CARGA_STATUS	/app/cargas/c47b1db8-984c-4f0f-9bc2-6ea83324b9e9	{"estado": "recogido", "cargaId": "c47b1db8-984c-4f0f-9bc2-6ea83324b9e9"}	1cecc249-b59e-4c68-9b87-85a2e98dd8ee	db1ed43d-aba6-47e7-a83b-f57b5f38c6c4	La carga ORD1758725870896 cambió a estado: recogido.
b0cfaf57-9c1d-418a-9e5a-b1b77c9987dc	2025-09-24 06:38:46.804	2025-09-24 06:38:46.804	\N	t	Cambio de estado de tu carga	f	CARGA_STATUS	/app/cargas/c47b1db8-984c-4f0f-9bc2-6ea83324b9e9	{"estado": "en_transito", "cargaId": "c47b1db8-984c-4f0f-9bc2-6ea83324b9e9"}	1cecc249-b59e-4c68-9b87-85a2e98dd8ee	db1ed43d-aba6-47e7-a83b-f57b5f38c6c4	La carga ORD1758725870896 cambió a estado: en_transito.
9a81be08-7724-4e3b-b367-7d87aee563a2	2025-09-24 06:38:46.804	2025-09-24 06:38:46.804	\N	t	Cambio de estado de tu carga	f	CARGA_STATUS	/app/cargas/c47b1db8-984c-4f0f-9bc2-6ea83324b9e9	{"estado": "llegado_al_destino", "cargaId": "c47b1db8-984c-4f0f-9bc2-6ea83324b9e9"}	1cecc249-b59e-4c68-9b87-85a2e98dd8ee	db1ed43d-aba6-47e7-a83b-f57b5f38c6c4	La carga ORD1758725870896 cambió a estado: llegado_al_destino.
64e16d30-3309-4dc5-993c-878681123564	2025-09-24 06:38:46.804	2025-09-24 06:38:46.804	\N	t	Cambio de estado de tu carga	f	CARGA_STATUS	/app/cargas/c47b1db8-984c-4f0f-9bc2-6ea83324b9e9	{"estado": "en_reparto_final", "cargaId": "c47b1db8-984c-4f0f-9bc2-6ea83324b9e9"}	1cecc249-b59e-4c68-9b87-85a2e98dd8ee	db1ed43d-aba6-47e7-a83b-f57b5f38c6c4	La carga ORD1758725870896 cambió a estado: en_reparto_final.
17bf3094-8a3c-48be-98d7-62de89b18ff8	2025-10-24 09:12:11.531	2025-10-24 09:12:11.531	\N	t	Propuesta aceptada	f	proposal_accepted	/app/proposals/0f837284-07ff-4f40-8d00-363159c6edcb	{"action": "confirm_assignment", "cargaId": "de69bd35-3fdd-463d-a19c-55864d809aae", "proposalId": "0f837284-07ff-4f40-8d00-363159c6edcb"}	55454c37-5700-4f42-9597-dfd19efd0ad2	4b097939-a723-44d6-ad1c-2b069dd5f8c4	ENSA Empresa Nacional de Servicios Aéreos ha aceptado la propuesta para la carga ORD1757568598901. Confirma para asignar.
1ecc1e6d-ed5c-4d1e-a7f9-13ae1ca63a17	2025-11-14 05:19:03.736	2025-11-14 05:19:03.736	\N	t	Asignación confirmada	f	proposal_confirmed	/app/cargas/de69bd35-3fdd-463d-a19c-55864d809aae	{"cargaId": "de69bd35-3fdd-463d-a19c-55864d809aae", "proposalId": "cc7391d7-cc2d-4d9c-9345-48c6f7edc638"}	b1a62649-8f51-47e9-99d3-3aa080126bf6	82a806d2-2f4f-4857-8460-d762da2e694b	El cliente confirmó la asignación de la carga ORD1757568598901. Procede con la gestión.
6ad9e100-a925-4728-885d-6e6c210936d0	2025-12-15 11:09:48.81	2025-12-15 11:09:48.81	\N	t	Cambio de estado de tu carga	f	CARGA_STATUS	/app/cargas/de69bd35-3fdd-463d-a19c-55864d809aae	{"estado": "listo_para_recoger", "cargaId": "de69bd35-3fdd-463d-a19c-55864d809aae"}	82a806d2-2f4f-4857-8460-d762da2e694b	4b097939-a723-44d6-ad1c-2b069dd5f8c4	La carga ORD1757568598901 cambió a estado: listo_para_recoger.
41c447b5-c9c0-41d3-beb7-fa741185699e	2025-11-14 00:40:17.473172	2025-11-14 05:19:03.736	\N	t	Propuesta aceptada	t	proposal_accepted	/app/proposals/cc7391d7-cc2d-4d9c-9345-48c6f7edc638	{"action": "confirm_assignment", "cargaId": "de69bd35-3fdd-463d-a19c-55864d809aae", "confirmed": true, "proposalId": "cc7391d7-cc2d-4d9c-9345-48c6f7edc638"}	82a806d2-2f4f-4857-8460-d762da2e694b	b1a62649-8f51-47e9-99d3-3aa080126bf6	Agencia Nova Nova Cuba ha aceptado la propuesta para la carga ORD1757568598901. Confirma para asignar.
a0f381a7-4a39-4d4c-aba6-334c0f2a28f9	2025-12-15 11:09:48.81	2025-12-15 11:09:48.81	\N	t	Cambio de estado de tu carga	f	CARGA_STATUS	/app/cargas/de69bd35-3fdd-463d-a19c-55864d809aae	{"estado": "recogido", "cargaId": "de69bd35-3fdd-463d-a19c-55864d809aae"}	82a806d2-2f4f-4857-8460-d762da2e694b	4b097939-a723-44d6-ad1c-2b069dd5f8c4	La carga ORD1757568598901 cambió a estado: recogido.
1431356a-9c84-4571-8fc3-0216de3631de	2025-12-15 11:09:48.81	2025-12-15 11:09:48.81	\N	t	Nueva propuesta de carga	f	proposal	/proposals/3c863017-5a6a-411a-a67f-3045da98b67b	{"cargaId": "89c2ebff-4e93-4f0c-9c03-e60a823dae87", "proposalId": "3c863017-5a6a-411a-a67f-3045da98b67b"}	b1a62649-8f51-47e9-99d3-3aa080126bf6	698b5a78-92db-4076-8e28-55f5c6e27f69	Dariel te ha propuesto la carga ORD1757568797396.
692c4c27-e7fa-4b2e-b7aa-cdaa5839141d	2025-12-15 11:09:48.81	2025-12-15 11:09:48.81	\N	t	Asignación confirmada	f	proposal_confirmed	/app/cargas/89c2ebff-4e93-4f0c-9c03-e60a823dae87	{"cargaId": "89c2ebff-4e93-4f0c-9c03-e60a823dae87", "proposalId": "3c863017-5a6a-411a-a67f-3045da98b67b"}	b1a62649-8f51-47e9-99d3-3aa080126bf6	698b5a78-92db-4076-8e28-55f5c6e27f69	El cliente confirmó la asignación de la carga ORD1757568797396. Procede con la gestión.
3c7b43f2-54ba-4cd2-a9dd-076d589341fe	2025-12-18 10:53:31.568185	2025-12-15 11:09:48.81	\N	t	Propuesta aceptada	t	proposal_accepted	/app/proposals/3c863017-5a6a-411a-a67f-3045da98b67b	{"action": "confirm_assignment", "cargaId": "89c2ebff-4e93-4f0c-9c03-e60a823dae87", "confirmed": true, "proposalId": "3c863017-5a6a-411a-a67f-3045da98b67b"}	698b5a78-92db-4076-8e28-55f5c6e27f69	b1a62649-8f51-47e9-99d3-3aa080126bf6	Mypime F&F Fast and Furious ha aceptado la propuesta para la carga ORD1757568797396. Confirma para asignar.
21540054-ec62-4f2a-926c-f7bb5898e1a9	2026-01-18 22:10:04.622	2026-01-18 22:10:04.622	\N	t	Nueva propuesta de carga	f	proposal	/proposals/1037a7b1-b6c1-4ffb-9aae-cc59c3cdfaff	{"cargaId": "53952cbe-7388-4e6b-9c80-3cd118558c10", "proposalId": "1037a7b1-b6c1-4ffb-9aae-cc59c3cdfaff"}	db1ed43d-aba6-47e7-a83b-f57b5f38c6c4	698b5a78-92db-4076-8e28-55f5c6e27f69	Hassan te ha propuesto la carga ORD1770400119512.
360ae20f-73fc-4b23-baa4-2acde0c48331	2026-01-18 22:10:04.622	2026-01-18 22:10:04.622	\N	t	Asignación confirmada	f	proposal_confirmed	/app/cargas/53952cbe-7388-4e6b-9c80-3cd118558c10	{"cargaId": "53952cbe-7388-4e6b-9c80-3cd118558c10", "proposalId": "1037a7b1-b6c1-4ffb-9aae-cc59c3cdfaff"}	db1ed43d-aba6-47e7-a83b-f57b5f38c6c4	698b5a78-92db-4076-8e28-55f5c6e27f69	El cliente confirmó la asignación de la carga ORD1770400119512. Procede con la gestión.
f5364ea7-74b9-4476-9862-e5ebdce7d1c3	2026-02-06 12:55:47.760235	2026-01-18 22:10:04.622	\N	t	Propuesta aceptada	t	proposal_accepted	/app/proposals/1037a7b1-b6c1-4ffb-9aae-cc59c3cdfaff	{"action": "confirm_assignment", "cargaId": "53952cbe-7388-4e6b-9c80-3cd118558c10", "confirmed": true, "proposalId": "1037a7b1-b6c1-4ffb-9aae-cc59c3cdfaff"}	698b5a78-92db-4076-8e28-55f5c6e27f69	db1ed43d-aba6-47e7-a83b-f57b5f38c6c4	Mypime F&F Fast and Furious ha aceptado la propuesta para la carga ORD1770400119512. Confirma para asignar.
71d7d441-bb14-4047-afb5-93972a6cb2fa	2026-03-13 15:35:22.184186	2025-09-21 07:19:50.802	\N	t	Nueva propuesta de carga	t	proposal	/proposals/02a6d09f-67ab-4200-b779-f5ed02102b19	{"cargaId": "de69bd35-3fdd-463d-a19c-55864d809aae", "proposalId": "02a6d09f-67ab-4200-b779-f5ed02102b19"}	4b097939-a723-44d6-ad1c-2b069dd5f8c4	49041db6-0a38-4678-a195-5e1ab02222b2	Ariel te ha propuesto la carga ORD1757568598901.
bc1ab98b-8e2a-44f7-95fc-f03367708eb1	2026-08-09 20:19:59.502	2026-08-09 20:19:59.503	\N	t	Propuesta aceptada	f	proposal_accepted	/app/proposals/f2023572-b8e1-4d9d-ba0a-d62ad08beeac	{"action": "confirm_assignment", "cargaId": "94c41559-2f93-488d-afb9-9077d78d287e", "proposalId": "f2023572-b8e1-4d9d-ba0a-d62ad08beeac"}	55454c37-5700-4f42-9597-dfd19efd0ad2	4b097939-a723-44d6-ad1c-2b069dd5f8c4	ENSA Empresa Nacional de Servicios Aéreos ha aceptado la propuesta para ORD1786456905956. Confirma para asignar. Datos del vehículo: ensa.
\.


--
-- Data for Name: origen; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.origen (id, "updatedAt", "createdAt", _deleted_at, "isActive", name, description) FROM stdin;
5d349d63-dbff-48b9-9c54-5d612c1fac76	2025-07-26 19:28:12.61	2025-07-26 19:28:12.61	\N	t	Habana	Habana
3e696bc9-9150-4848-85c7-7e4f6cb9612b	2026-01-18 22:10:04.622	2026-01-18 22:10:04.622	\N	t	santiago	Viajes santiago - habana
55763971-f912-4d6d-a4b8-c667072afd99	2026-01-29 15:19:10.768595	2026-01-18 22:10:04.622	2026-01-29 15:19:10.768595	t	Pinar del Rio	Refresco
cb20bf75-48e8-400f-a34d-9cc0ff6ca14f	2026-02-19 05:24:07.362	2026-02-19 05:24:07.363	\N	t	Isla de la Juventud	Isla de la Juventud
\.


--
-- Data for Name: pago; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.pago (id, "updatedAt", "createdAt", _deleted_at, "isActive", name, description, "facturaNumero", monto, "fechaRegistro", "fechaFactura", estado, "customerId", comercial_id, "cuentaBancariaOrigen", reserva_id) FROM stdin;
\.


--
-- Data for Name: peticion; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.peticion (id, "nombreEntidad", "nombreCarga", peso, volumen, origen, destino, "tipoCarga", status, "createdAt", cliente_id, assigned_proposal_id, via, "origenDireccion", "destinoDireccion", "distanciaKm", "precioEstimado", transportista_prestatario_id) FROM stdin;
44e620fb-1a11-4485-b3d8-8f53a62400a4	ACUBAMOS	Arroz	25000	30	Habana	Habana	Seco	abierta	2026-03-07 14:54:41.694436-05	8f1bf5a7-2b13-4764-b7a8-1f76730bcfb4	\N	\N	\N	\N	\N	\N	\N
922d9491-d160-4463-915e-7439e2f60956	A	Bagazo	25000	16.4	Habana	Habana	Seco	abierta	2026-05-01 20:43:41.420036-04	8f1bf5a7-2b13-4764-b7a8-1f76730bcfb4	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: plan-servicio-cliente; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public."plan-servicio-cliente" (id, "updatedAt", "createdAt", _deleted_at, "isActive", servicio_id, plan_id) FROM stdin;
\.


--
-- Data for Name: plan-servicio-prestatario; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public."plan-servicio-prestatario" (id, "updatedAt", "createdAt", _deleted_at, "isActive") FROM stdin;
\.


--
-- Data for Name: planes; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.planes (id, "updatedAt", "createdAt", _deleted_at, "isActive", name, description, precio, prestatario) FROM stdin;
\.


--
-- Data for Name: prestatario; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.prestatario (id, "updatedAt", "createdAt", _deleted_at, "isActive", "tipoCarga", contenedor, transportes, ayudantes, "cargasEspeciales", rating, licencia, "user", "maxWeight", "maxVolume", name, servicios, conditions, "metrosDisponiblesAlquiler", "alturaMAlquiler", "serviciosPrestAlquiler", "talleresNumTecnicos", "talleresHorario", "talleresServicios", "talleresCapacidadVehiculos", "gpsProviders", "gpsDevicesAvailable", "gpsPlans", "gpsIntegrationApi", "habitacionesDisponibles", "capacidadPersonas", "precioNochePromedio", "tipoHabitaciones", "serviciosIncluidosAlojamiento", "precioTerrestre", "consumoGasolina", "tiposVehiculos", "capacidadPorTipo", disponible, "disponibilidadDesde", "disponibilidadHasta", "zonaCobertura", "cantidadCamiones", "talleresDireccion", "talleresPrecios", "talleresReservaCitas", "talleresHorarioInicio", "talleresHorarioFin", "talleresDiasDisponibles", es_taller, tiene_escatolina, capacidad_simultanea, requiere_aprobacion_citas, taller_direccion_id, default_aereo) FROM stdin;
cddafff0-8e7e-49a5-b89a-8e29e693eeb2	2025-09-11 05:12:03.318	2025-09-11 05:12:03.319	\N	t	Carga general	40	[{"chapa": "mnbmn3244r3", "nombreChofer": "Pepe Perez", "tipoTransporte": "Camión"}, {"chapa": "7s8gdwg87w", "nombreChofer": "Mecha Maturin", "tipoTransporte": "Otro"}]	[{"ci": "9876356748267", "nombre": "Alejandro", "apellidos": "Socorro Socas"}, {"ci": "97383940365", "nombre": "Pedro", "apellidos": "Kolo"}]	["Especial 1"]	3	{"vence": "2025-09-30", "numero": "92n293ud2n93ud", "categoria": "G5"}	698b5a78-92db-4076-8e28-55f5c6e27f69	1700	70	Mypime F&F Fast and Furious	{aerea,terrestre}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	[]	{}	t	\N	\N	{}	\N	\N	\N	f	\N	\N	\N	f	f	\N	t	\N	f
176c783a-ab19-429c-b2db-29d95ce0d840	2025-10-20 05:26:21.335	2025-10-20 05:26:21.336	\N	t	Seco	20	[{"chapa": "JM67J67J67J", "nombreChofer": "NMHNMHJUN", "tipoTransporte": "Camión"}, {"chapa": "5JIMOI45JTUI4J5", "nombreChofer": "SIKIK8K", "tipoTransporte": "Camioneta"}]	[{"ci": "9567567566464", "nombre": "WEFWEF", "apellidos": "WEFWEFWE"}, {"ci": "9028973283648", "nombre": "SADHRGFHTYHJTY", "apellidos": "HRRTHRTHR"}]	["wefwefwef", "wefwef"]	5	{"vence": "2025-10-31", "numero": "NK9ASDA89S", "categoria": "B5"}	a6c78d3b-83d4-446f-8529-50b793f91285	34	456	Test TEST	{aerea,terrestre}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	[]	{}	t	\N	\N	{}	\N	\N	\N	f	\N	\N	\N	f	f	\N	t	\N	f
6e1b8b74-9d35-47ee-841f-6e81580f7b52	2025-10-24 14:29:46.449	2025-10-24 14:29:46.449	\N	t	Carga general	40	[]	[]	[]	\N	{"vence": "2025-10-24", "numero": "Hsbsbs", "categoria": "Camion"}	6412345c-5baa-4f69-a436-ea0c6a186972	100	100	Ramon Rodriguez	{terrestre}	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	[]	{}	t	\N	\N	{}	\N	\N	\N	f	\N	\N	\N	f	f	\N	t	\N	f
df137d33-e5d7-44d3-b796-d8d720d9fc38	2026-05-04 16:42:52.064248	2025-09-11 05:12:03.319	\N	t	Seco	20	[{"chapa": "HJBJH2B323", "nombreChofer": "Nicolas Sanchez", "tipoTransporte": "Camión"}, {"chapa": "N83DN238N", "nombreChofer": "Lazaro Pineira", "tipoTransporte": "Camioneta"}]	[{"ci": "90262524231", "nombre": "Mario", "apellidos": "Nodal"}]	["Minerales"]	2	{"vence": "2026-01-23", "numero": "8UWNBWNWE98", "categoria": "P9"}	82a806d2-2f4f-4857-8460-d762da2e694b	500	23	Agencia Nova Nova Cuba	{terrestre}		\N	\N	[]	\N		[]	\N	[]	\N		f	\N	\N	\N	[]	[]	\N	0.00	[]	{}	t	\N	\N	{}	\N	\N	\N	f	\N	\N	\N	f	f	\N	t	\N	f
681e455f-b63a-4381-8126-3caf9ca968f4	2026-05-05 12:04:43.730152	2025-09-03 06:38:18.082	\N	t	Carga general	40	[{"chapa": "HB2JHBD32JBD", "nombreChofer": "Chofer 1", "tipoTransporte": "Otro"}, {"chapa": "P033353", "nombreChofer": "Paco", "tipoTransporte": "Camión"}]	[{"ci": "929389237233", "nombre": "Ayudante 3", "apellidos": "Auxiliar 3"}]	["Especial Test"]	5	{"vence": "2026-01-30", "numero": "B3IHU34F3", "categoria": "M3"}	1cecc249-b59e-4c68-9b87-85a2e98dd8ee	2000	567	Alejandro Acubamos Test	{terrestre}		\N	\N	[]	\N		[]	\N	[]	\N		f	\N	\N	\N	[]	[]	\N	0.00	[]	{}	t	\N	\N	{}	\N	\N	\N	f	\N	\N	\N	f	f	\N	t	\N	f
92898c95-a50d-41db-ae54-12185e1595fa	2026-05-05 14:46:13.526	2026-05-05 14:46:13.527	\N	t	Carga general	20	[{"chapa": "P033535", "nombreChofer": "Paco", "tipoTransporte": "Camión"}]	[]	[]	4	{"vence": "2028-05-09", "numero": "92837465102", "categoria": "C"}	53af6439-898e-4ac9-8256-6952b0326e7a	100	40	Rosca Izquierdo Suares	{terrestre}	\N	\N	\N	[]	\N		[]	\N	[]	\N		f	\N	\N	\N	[]	[]	\N	0.00	[]	{}	t	\N	\N	{}	\N	\N	\N	f	\N	\N	\N	f	f	\N	t	\N	f
f589acae-f1fb-46b9-8ec6-dede1ef83a56	2026-08-10 18:01:28.562919	2025-09-11 05:12:03.319	\N	t	Seco	40	[{"chapa": "89nhdnhj2d8", "nombreChofer": "Carlos Lopez Quesada", "tipoTransporte": "Otro"}, {"chapa": "sad7asd8", "nombreChofer": "Marcos Galban Lazo", "tipoTransporte": "Otro"}]	[{"ci": "98373635474", "nombre": "Ayudante 1", "apellidos": "Pacp Paco"}]	[]	4	{"vence": "2025-09-30", "numero": "89yhhqw7bn7", "categoria": "b4"}	55454c37-5700-4f42-9597-dfd19efd0ad2	1200	900	ENSA Empresa Nacional de Servicios Aéreos	{aerea}		\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	0.00	[]	{}	t	\N	\N	{}	\N	\N	\N	f	\N	\N	\N	f	f	\N	t	\N	t
2947b821-7a03-4c36-9e25-4d598cf0f7d6	2026-08-13 13:27:32.111033	2025-09-03 06:38:18.082	\N	t	Seco	40	[{"chapa": "fligth205", "nombreChofer": "Avioneta 203", "tipoTransporte": "Otro", "cargasEspeciales": []}, {"chapa": "d3d34d", "nombreChofer": "Jet", "tipoTransporte": "Otro", "cargasEspeciales": ["a", "b"]}, {"chapa": "mndmndN", "nombreChofer": "Camion", "tipoTransporte": "Camión", "cargasEspeciales": []}, {"chapa": "", "nombreChofer": "", "tipoTransporte": "", "cargasEspeciales": ["a"]}]	[{"ci": "928372638762678", "nombre": "Ayudante", "apellidos": "Auxiliar", "direccion": ""}, {"ci": "8972389289378293", "nombre": "Ayudante 2", "apellidos": "Auxiliar 2", "direccion": ""}]	[]	3	{"vence": "2025-09-26", "numero": "JH23HJ2", "categoria": "F2", "descripcion": ""}	49041db6-0a38-4678-a195-5e1ab02222b2	1300	400	Amel Acubamos Test	{terrestre,aerea}		\N	\N	[]	\N		[]	\N	[]	\N		f	\N	\N	\N	[]	[]	{"precioPorKm": 0}	0.00	[]	{}	t	\N	\N	{}	\N	\N	\N	f	\N	\N	\N	f	f	\N	t	\N	f
\.


--
-- Data for Name: prestatarios; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.prestatarios (id, "updatedAt", "createdAt", _deleted_at, "isActive", "tipoCarga", contenedor, transportes, ayudantes, "cargasEspeciales", rating, licencia, "maxWeight", "maxVolume", user_id) FROM stdin;
\.


--
-- Data for Name: prestatarioserv; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.prestatarioserv (id, "updatedAt", "createdAt", _deleted_at, "isActive", name, description, descripcion, prestatario_id, servicio_id, precio) FROM stdin;
\.


--
-- Data for Name: proposal; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.proposal (id, status, message, "createdAt", "cargaId", "prestatarioId", "proposerId", carta_generated, "assignedVehicle", "peticionId") FROM stdin;
216ebc71-f116-41b9-92e3-53cc2488ede6	confirmed	...optional	2025-09-24 10:38:00.521398	e2d97a60-5c46-407e-a625-d08a9262a868	681e455f-b63a-4381-8126-3caf9ca968f4	b1a62649-8f51-47e9-99d3-3aa080126bf6	f	\N	\N
34c48f0a-f7c2-4624-a7a6-c501c285e0ed	accepted	...optional	2025-09-24 10:50:11.167411	89c2ebff-4e93-4f0c-9c03-e60a823dae87	cddafff0-8e7e-49a5-b89a-8e29e693eeb2	b1a62649-8f51-47e9-99d3-3aa080126bf6	f	\N	\N
0f837284-07ff-4f40-8d00-363159c6edcb	accepted	...optional	2025-09-24 02:01:40.431527	de69bd35-3fdd-463d-a19c-55864d809aae	f589acae-f1fb-46b9-8ec6-dede1ef83a56	4b097939-a723-44d6-ad1c-2b069dd5f8c4	f	\N	\N
cc7391d7-cc2d-4d9c-9345-48c6f7edc638	confirmed	...optional	2025-11-14 00:39:48.102823	de69bd35-3fdd-463d-a19c-55864d809aae	df137d33-e5d7-44d3-b796-d8d720d9fc38	b1a62649-8f51-47e9-99d3-3aa080126bf6	t	\N	\N
3c863017-5a6a-411a-a67f-3045da98b67b	confirmed	...optional	2025-12-18 10:50:36.977458	89c2ebff-4e93-4f0c-9c03-e60a823dae87	cddafff0-8e7e-49a5-b89a-8e29e693eeb2	b1a62649-8f51-47e9-99d3-3aa080126bf6	f	\N	\N
1037a7b1-b6c1-4ffb-9aae-cc59c3cdfaff	confirmed	...optional	2026-02-06 12:53:19.958225	53952cbe-7388-4e6b-9c80-3cd118558c10	cddafff0-8e7e-49a5-b89a-8e29e693eeb2	db1ed43d-aba6-47e7-a83b-f57b5f38c6c4	f	\N	\N
5376ecd1-c4e3-4a1e-b2a6-140939209562	pending	Propuesta generada automáticamente	2026-08-10 18:03:37.698975	5e4f3ecc-f226-4932-a651-cd376e58f6ee	f589acae-f1fb-46b9-8ec6-dede1ef83a56	4b097939-a723-44d6-ad1c-2b069dd5f8c4	f	\N	\N
f2023572-b8e1-4d9d-ba0a-d62ad08beeac	accepted	Propuesta generada automáticamente	2026-08-11 10:01:33.641724	94c41559-2f93-488d-afb9-9077d78d287e	f589acae-f1fb-46b9-8ec6-dede1ef83a56	4b097939-a723-44d6-ad1c-2b069dd5f8c4	f	{"vehiculo_pertenece_a":"ensa","conducido_por":"ensa otro","chapa_no":"12","lot_no":"22","hoja_ruta_no":"3","chapa_tractivo_no":"1","remolque_no":"1","carta_porte_no":"1","carne_identidad_conductor":"1","licencia_conduccion_no":"1","basificado_en":"1"}	\N
7cf4e5da-a9e8-4174-9225-5c685205101f	pending	...optional	2026-08-11 17:00:55.429679	6f1d37fe-e17c-4ef5-bdf2-9f1f15008118	f589acae-f1fb-46b9-8ec6-dede1ef83a56	45f28bf4-2268-4f7e-93ba-1f9176f62bfe	f	\N	\N
\.


--
-- Data for Name: proposals_alquiler; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.proposals_alquiler (id, status, message, carta_generated, "createdAt", "updatedAt", "solicitudId", "prestatarioId", "proposerId") FROM stdin;
\.


--
-- Data for Name: proposals_services; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.proposals_services (id, status, "serviceType", message, carta_generated, "createdAt", "updatedAt", solicitud_id, prestatario_id, proposer_id) FROM stdin;
\.


--
-- Data for Name: proveedores; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.proveedores (id, "updatedAt", "createdAt", _deleted_at, "isActive", name, description, "isUsed", email, phone, direccion) FROM stdin;
\.


--
-- Data for Name: province; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.province (id, "updatedAt", "createdAt", _deleted_at, "isActive", name, description, "isUsed", country_id) FROM stdin;
\.


--
-- Data for Name: reserva; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.reserva (id, "updatedAt", "createdAt", _deleted_at, "isActive", name, description, apellido, correo, fecha, hora, direccion, state, vin, motor, bl, contenedor, "nombreSolicitante", "correoSolicitante", "telefonoSolicitante", "fechaSolicitud", comentarios, "comercialId", "servicioId", "userId") FROM stdin;
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.roles (id, "updatedAt", "createdAt", _deleted_at, "isActive", name, description) FROM stdin;
792e024b-f781-4f39-ba6a-2445fc1db712	2025-08-02 15:45:24.315	2025-08-02 15:45:24.315	\N	t	Administrador	admin
cc42a0e2-f339-495b-b147-ab1e53cbdf7d	2025-08-02 15:45:24.315	2025-08-02 15:45:24.315	\N	t	Prestatario	prestatario
31007a7f-b624-4bf9-b4d4-a296c46e083d	2025-08-12 05:23:53.184	2025-08-12 05:23:53.184	\N	t	Cliente	cliente
\.


--
-- Data for Name: servicio; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.servicio (id, "updatedAt", "createdAt", _deleted_at, "isActive", name, description, prestatario) FROM stdin;
\.


--
-- Data for Name: setting; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.setting (id, "updatedAt", "createdAt", _deleted_at, "isActive", key, value, type) FROM stdin;
bc3906c5-4a77-4fc3-9cc4-fca29ede642a	2025-09-11 03:15:45.617355	2025-09-11 06:46:20.817	\N	t	politica_cancelaciones	Cancelaciones gratuitas si se realizan con al menos 24 horas de antelación. Cancelaciones dentro de las 24 horas previas al retiro tienen una comisión. Las cargas ya recogidas o en tránsito no son reembolsables; para devoluciones contactar soporte.\n\nAlcance\n\nEsta política aplica a todas las órdenes gestionadas a través de la plataforma TMS (en adelante “la Plataforma”).\n\nCancelación por parte del remitente/cliente\n\nCancelación con ≥ 24 horas de antelación al horario de retiro programado: sin cargos, se reembolsa cualquier importe ya pagado (si aplica).\n\nCancelación dentro de las 24 horas previas al retiro: comisión de cancelación equivalente al 20% del valor de la orden o una tarifa mínima de [MONTO], lo que resulte mayor.\n\nCancelación después de que la mercancía haya sido recogida: no reembolsable. Si la devolución es posible, se aplicarán cargos de retorno y gestión.\n\nCancelación por parte del transportista o la empresa\n\nLa Plataforma o el prestatario podrán cancelar por causa justificada (avería, imposibilidad operativa, fuerza mayor). En dichos casos se ofrecerá al cliente la opción de reprogramar o recibir reembolso completo si no se reprograma en 48 horas.\n\nReembolsos\n\nLas solicitudes de reembolso serán procesadas una vez confirmada la cancelación. Los reembolsos se emitirán al método de pago original en un plazo estimado de 7–14 días hábiles.\n\nGastos administrativos, comisiones de pasarela o cargos de terceros pueden deducirse del importe reembolsado si estuvieran especificados en la orden.\n\nSolicitud de cancelación\n\nEl cliente debe solicitar la cancelación mediante la sección “Mis órdenes” en la Plataforma o contactando a soporte con: número de orden, motivo y datos de contacto.\n\nLas cancelaciones solicitadas por canales distintos a la Plataforma podrán requerir verificación adicional.\n\nExcepciones y fuerza mayor\n\nEventos de fuerza mayor (clima extremo, huelgas, restricciones gubernamentales) pueden modificar los plazos y condiciones; la Plataforma se compromete a notificar y ofrecer alternativas razonables.\n\nDisputas\n\nCualquier disputa relativa a cargos por cancelación deberá notificarse en un plazo de 14 días desde la fecha de cargo.	markdown
369c35ce-ee6e-46f2-b3f8-2a2cceb1e3c5	2025-09-11 03:14:47.084207	2025-09-11 06:46:20.817	\N	t	politica_entregas	Realizamos hasta 2 intentos de entrega. Para marcar como entregado se solicita firma y/o foto del DNI según el servicio. Reclamos por daño/pérdida deben reportarse dentro de 48 horas desde la entrega.\n\n* **Ventana y compromiso de entrega**\n    * Las entregas se realizarán en el rango horario acordado al momento de la programación. Los tiempos indicados son estimados y pueden verse afectados por condiciones externas.\n* **Intentos de entrega**\n    * Se realizarán hasta **2 intentos** de entrega sin coste adicional. Si el destinatario no se encuentra, la carga podrá reprogramarse; puede aplicarse una tarifa por reentrega.\n* **Prueba de entrega (POD)**\n    * Para completar la entrega se requiere una de las siguientes pruebas según el servicio contratado:\n        * Firma del destinatario en dispositivo móvil; y/o\n        * Fotografía del DNI (frente y dorso) y foto del receptor firmando; y/o\n        * Foto del paquete entregado en el lugar acordado.\n    * El transportista subirá el POD a la Plataforma. La ausencia de POD válido puede retrasar la confirmación de entrega y la resolución de reclamos.\n* **Entregas condicionadas**\n    * Si la entrega requiere autorización de un tercero o documento específico, el cliente debe proporcionarlo; de lo contrario la entrega podrá ser reprogramada.\n* **Responsabilidad por daños y pérdidas**\n    * El cliente debe inspeccionar la mercancía al recibirla y reportar daños o faltantes **dentro de las 48 horas** posteriores a la entrega.\n    * Reclamos válidos deberán incluir: fotos del embalaje, fotos del daño, estado del sello (si aplica), documento de entrega y reporte detallado.\n    * La responsabilidad de la Plataforma puede estar sujeta a límites (p. ej. valor declarado, cobertura contratada). Consulte tarifas y seguros adicionales.\n* **Reprogramaciones**\n    * Reprogramar una entrega puede implicar cargos según la antelación y la intervención necesaria; reprogramaciones con ≥ 24 horas de antelación no tendrán cargo, salvo caso contrario indicado en la orden.\n* **Retrasos**\n    * Retrasos causados por condiciones externas (clima, aduanas, incidentes viales) no son responsabilidad directa del transportista; la Plataforma informará y propondrá opciones.\n* **Procedimiento de reclamo**\n    * Abrir reclamo en la Plataforma o contacto de soporte indicando número de orden, descripción, fotos y documentos. Tiempo de respuesta inicial: 48–72 horas hábiles.	markdown
7740dcbf-b41c-4327-b1a3-d5a2c766bc6b	2025-09-18 02:00:30.760194	2025-09-11 06:46:20.817	\N	t	emergencias	rbtrtbrt	markdown
f5c6da5d-5119-4d46-9e13-be9a92b37722	2025-09-18 02:01:32.91514	2025-09-11 06:46:20.817	\N	t	prohibited_products	No se permite el transporte de sustancias peligrosas, armas de fuego, explosivos, drogas ilegales o cualquier artículo que pueda poner en riesgo la seguridad del transporte.	markdown
a865141b-415a-426f-95c6-e06486281be2	2025-09-11 03:12:23.145832	2025-09-11 06:46:20.817	\N	t	precio_destinos	El precio de cada envío se calcula con base en tarifa base + distancia/zona + peso/volumen + recargos (combustible, peajes, aduanas) y servicios adicionales (urgente, manipulación especial, seguro). Las tarifas se muestran antes de confirmar la orden y pueden aplicarse cargos extra por reprogramaciones o cambios en la ruta.\n\n* **Cálculo de precio**\n    * **Tarifa base:** importe fijo por orden (ej. tarifa mínima administrativa).\n    * **Componente por peso o volumen:** se calcula el mayor entre (tarifa por kg × peso) y (tarifa por m³ × volumen total). Por ejemplo: 70 CUP/kg o 100 CUP/m³.\n    * **Recargo por zona / distancia:** la plataforma aplica multiplicadores por zonas (urbano, suburbano, interprovincial, internacional) o una tarifa por km. Ejemplo: Zona urbana ×1.0, interprovincial ×1.3.\n    * **Recargo combustible:** porcentaje variable según precio de combustible (se aplica como % sobre subtotal).\n    * **Peajes y tasas:** se añaden gastos directos de peajes, tasas portuarias o aduanas según la ruta.\n    * **Servicios adicionales:** reexpedición, entrega en horario específico, manipulación especial, embalaje, seguro declarado, etc., con precios unitarios que se suman al total.\n    * **Impuestos:** impuestos aplicables según jurisdicción se agregan al final.\n* **Tarifa mínima y ejemplo**\n    * Se garantiza una tarifa mínima por orden: ej. 150 CUP.\n    * Ejemplo de cálculo (simplificado):\n        * Tarifa base: 150 CUP\n        * Peso 10 kg × 70 = 700 CUP\n        * Volumen 0.5 m³ × 100 = 50 CUP → usar 700 (mayor)\n        * Subtotal = 150 + 700 = 850 CUP\n        * Zona interprovincial (×1.2) => 1,020 CUP\n        * Recargo combustible 5% => 1,071 CUP\n        * Peajes 100 CUP => 1,171 CUP\n        * Impuesto (p. ej. 5%) => 1,229.55 CUP\n        * Total final ≈ 1,230 CUP\n* **Cargos adicionales y ajustes**\n    * Cambios de dirección o reprogramaciones solicitadas una vez iniciado el proceso pueden generar cargos (reentrega, desplazamiento extra).\n    * Si durante la recogida o entrega se detecta un peso/volumen distinto al declarado, se ajustará la tarifa y se notificará al cliente.\n    * Servicios especiales (fragile, temperatura controlada, manipulación con grúa, etc.) deben contratarse antes de la recogida; si se solicitan en tránsito se aplicará tarifa extra.\n* **Presupuestos y cotizaciones**\n    * La Plataforma puede emitir cotizaciones fijando precios por un periodo limitado (ej. 48 horas). Las cotizaciones pueden requerir aprobación manual para mercancías especiales.\n* **Facturación y pago**\n    * El precio final se mostrará en el resumen de la orden antes de confirmar. Los pagos pueden exigirse por adelantado cuando aplique (servicios internacionales, cargas valiosas o clientes nuevos).\n    * Facturas y desgloses estarán disponibles para descarga una vez procesada la orden.\n* **Transparencia**\n    * Todas las partidas (tarifa base, componentes, recargos, impuestos) estarán desglosadas en la factura. Ante consultas el cliente puede solicitar desglose detallado a soporte.	markdown
\.


--
-- Data for Name: solicitudes; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.solicitudes (id, solicitante, telefono, email, empresa, metros_requeridos, altura_m, fecha_inicio, duracion, acceso_horario, control_temperatura, servicios, frecuencia, clasificacion_mercancia, comentarios, cliente_id, assigned_prestatario_id, status, created_at, updated_at, fecha_fin, habitaciones_requeridas, personas, device_count, plan, vehiculo_marca, vehiculo_placa, service_requested, created_by_prestatario_id, tipo_uso, seguro_adquirido, valor_factura, tipo_carga_seguro, factura_url, costo_seguro) FROM stdin;
41274230-6856-4e3c-b2a3-6f8eee465bff	Ariel Gonzalez Martinez	56537338	ariel@gmail.com	FIAT	43	65	2025-11-29	3 meses	Horario comercial	Refrigerado	Preparación de pedidos,Transporte,Inspección	Semanal	\N	owiefwneovbwoevbwevwevwj\njwbneiucbnwiebvowebvoiwneoivnwoenow oefnwefo we f\nOWNEOEIWNEINWOE VOW	\N	\N	pending	2025-11-27 09:39:32.662501-05	2025-11-27 09:39:32.662501-05	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
5d546e9e-1dbd-4e37-9792-d09c056ba1ae	Nanda Lopez Gonzales	57493830	nanda@gmail.com	LOLO	98	56	2025-12-04	3 meses	Horario comercial	Congelado	Pick & Pack,Etiquetado,Transporte	Varias veces al día	\N	uihygtctu yguygu huih iuwh iuhi hi h\nioj iowhjiuhweuihiwuehifuhjwoiefjowiejfojweiof	\N	\N	pending	2025-11-27 09:42:48.758332-05	2025-11-27 09:42:48.758332-05	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
9c86e4b1-8582-477c-b088-d92383e28da6	Amel	5555555	presidencia@acubamos.cu	Acubamos	2000	\N	2026-01-26	1 mes	24/7	\N		\N	\N	\N	\N	\N	pending	2026-01-22 09:48:38.165708-05	2026-01-22 09:48:38.165708-05	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
547f30f6-7a5e-4451-859e-b9f9b0a37654	Amel	5555555	presidencia@acubamos.cu	Acubamos	2000	\N	2026-01-26	1 mes	24/7	\N		\N	\N	\N	\N	\N	pending	2026-01-22 09:48:47.031536-05	2026-01-22 09:48:47.031536-05	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	\N	\N	\N
dfe8e4ac-f52d-4b27-b4df-70ceb902e7a2	GPS	455465456	pepe@gmail.com	Gcom	0	\N	\N	\N	\N	\N		\N	\N	Donde esta el precio  del servicio que estoy creando	\N	\N	pending	2026-03-07 16:38:44.150623-05	2026-03-07 16:38:44.150623-05	\N	\N	\N	1	Básico	\N	\N	gps	2947b821-7a03-4c36-9e25-4d598cf0f7d6	\N	f	\N	\N	\N	\N
930b87f3-9715-41c8-a1d8-0c9fdb48ca49	Pepe	465465465	aloja@gmail.com	Hotel	100	10	2026-03-07	1 mes	\N	\N		\N	\N	precio?????? que otras cosas incluye el almacen . tiene CCTV, guardias, perros	\N	\N	pending	2026-03-07 16:45:57.054251-05	2026-03-07 16:45:57.054251-05	\N	\N	\N	\N	\N	\N	\N	alquiler	2947b821-7a03-4c36-9e25-4d598cf0f7d6	\N	f	\N	\N	\N	\N
a1ea560d-19ab-4fec-bc17-9d4be16e963a	Pepe	1545661564	blabalana@gmail.com	Pepe transporte	0	\N	2026-03-08	\N	\N	\N		\N	\N	Precio? que incluye	\N	\N	pending	2026-03-07 16:48:06.459985-05	2026-03-07 16:48:06.459985-05	2026-03-10	3	3	\N	\N	\N	\N	alojamiento	2947b821-7a03-4c36-9e25-4d598cf0f7d6	\N	f	\N	\N	\N	\N
2b0a32b4-b3ca-4216-999b-57a92e8a6c88	pepe	14654132132	correo@gmail.com	Talleres Pepe SA	0	\N	\N	\N	\N	\N		\N	\N	Comentarios las reglas de este servicio. Donde esta el precio. Ventana de trabajo no cierra	\N	\N	pending	2026-03-07 16:42:26.55034-05	2026-03-07 16:42:26.55034-05	\N	\N	\N	\N	\N	?????	??????	taller	2947b821-7a03-4c36-9e25-4d598cf0f7d6	\N	f	\N	\N	\N	\N
b374da3f-6905-43b7-87f8-e8e70f316f05	Juan	111111111	ejemplo@abc.com	Juan	0	\N	\N	\N	\N	\N		\N	\N	No tiene precio	\N	\N	pending	2026-07-07 08:52:43.871605-04	2026-07-07 08:52:43.871605-04	\N	\N	\N	2	Básico	\N	\N	gps	2947b821-7a03-4c36-9e25-4d598cf0f7d6	\N	f	\N	\N	\N	0.00
3ed9af60-20fb-4d8b-b076-9e84e865553f	Juan	111111111	ejemplo@abc.com	Juan	0	\N	2026-07-07	\N	\N	\N		\N	\N	\N	\N	\N	pending	2026-07-07 08:54:43.439536-04	2026-07-07 08:54:43.439536-04	\N	\N	\N	\N	\N	\N	\N	seguro	2947b821-7a03-4c36-9e25-4d598cf0f7d6	\N	f	\N	\N	\N	0.00
5813c142-5e5f-4b9a-b0ac-7b35fccf694c	Pepe	444444444	pepe@pepe.com	gcom	0	\N	\N	\N	\N	\N		\N	\N	\N	\N	\N	pending	2026-07-22 15:06:20.467528-04	2026-07-22 15:06:20.467528-04	\N	\N	\N	5	Básico	\N	\N	gps	2947b821-7a03-4c36-9e25-4d598cf0f7d6	\N	f	\N	\N	\N	0.00
c0cee428-17f2-407e-a8c1-0782cb76c0a2	Taller Pepe	111111111	pepe@pepe.com	Amigos de pepe	0	\N	\N	\N	\N	\N		\N	\N	prueba	\N	\N	pending	2026-07-22 15:11:56.299879-04	2026-07-22 15:11:56.299879-04	\N	\N	\N	\N	\N	FIAT	U100888	taller	2947b821-7a03-4c36-9e25-4d598cf0f7d6	[{"price": 0, "value": "Diagnóstico"}]	f	\N	\N	\N	0.00
af9f7ad1-8b8b-4742-98dd-c83fc7404a87	pepe	1111111111	pepe@pepe.com	Pepe company	1000	10	2026-01-08	15 dias	\N	\N		\N	\N	\N	\N	\N	pending	2026-07-22 15:13:51.055352-04	2026-07-22 15:13:51.055352-04	\N	\N	\N	\N	\N	\N	\N	alquiler	2947b821-7a03-4c36-9e25-4d598cf0f7d6	\N	f	\N	\N	\N	0.00
218e44e3-57ef-4ec3-bc3a-861968002e1a	Pepe	1111111111	pepe@pepe.com	Pepe company	0	\N	2026-07-23	\N	\N	\N		\N	\N	\N	\N	\N	pending	2026-07-22 15:16:41.832029-04	2026-07-22 15:16:41.832029-04	2026-07-25	2	2	\N	\N	\N	\N	alojamiento	2947b821-7a03-4c36-9e25-4d598cf0f7d6	\N	f	\N	\N	\N	0.00
cab310f2-2d7f-4794-bcf3-8d38406cd5fe	pepe	111111111	pepe@pepe.com	pepe company	0	\N	2026-07-24	\N	\N	\N		\N	\N	\N	\N	\N	pending	2026-07-22 15:17:40.828258-04	2026-07-22 15:17:40.828258-04	\N	\N	\N	\N	\N	\N	\N	seguro	2947b821-7a03-4c36-9e25-4d598cf0f7d6	\N	f	\N	\N	\N	0.00
982f1250-c5d0-4b1a-bbf8-80b92bb05739	pepe	111111111	pepe@pepe.com	Pepe company	0	\N	\N	\N	\N	\N		\N	\N	\N	\N	\N	pending	2026-07-22 15:18:12.218633-04	2026-07-22 15:18:12.218633-04	\N	\N	\N	\N	\N	\N	\N	servicupet	2947b821-7a03-4c36-9e25-4d598cf0f7d6	\N	f	\N	\N	\N	0.00
\.


--
-- Data for Name: taller_horario; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.taller_horario (id, "updatedAt", "createdAt", _deleted_at, "isActive", dia_semana, hora_inicio, hora_fin, activo, prestatario_id) FROM stdin;
\.


--
-- Data for Name: taller_servicio; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.taller_servicio (id, "updatedAt", "createdAt", _deleted_at, "isActive", nombre_personalizado, tipo_servicio, precio_base, tiempo_estimado_minutos, activo, prestatario_id) FROM stdin;
\.


--
-- Data for Name: tipo_servicio_mecanico; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.tipo_servicio_mecanico (id, "updatedAt", "createdAt", _deleted_at, "isActive", codigo, nombre, descripcion, tiempo_estimado_minutos, activo) FROM stdin;
\.


--
-- Data for Name: tipocarga; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.tipocarga (id, "updatedAt", "createdAt", _deleted_at, "isActive", name, description, descripcion) FROM stdin;
\.


--
-- Data for Name: tipomercado; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.tipomercado (id, "updatedAt", "createdAt", _deleted_at, "isActive", name, description) FROM stdin;
\.


--
-- Data for Name: tipopago; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.tipopago (id, "updatedAt", "createdAt", _deleted_at, "isActive", name, description) FROM stdin;
\.


--
-- Data for Name: tipos_um; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.tipos_um (id, "updatedAt", "createdAt", _deleted_at, "isActive", name, description, "isUsed") FROM stdin;
\.


--
-- Data for Name: tipotransporte; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.tipotransporte (id, "updatedAt", "createdAt", _deleted_at, "isActive", name, description) FROM stdin;
\.


--
-- Data for Name: tipoviaje; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.tipoviaje (id, "updatedAt", "createdAt", _deleted_at, "isActive", name, description) FROM stdin;
8dbde88b-1a33-4253-aa5d-f5298437a06a	2026-01-18 22:10:04.622	2026-01-18 22:10:04.622	\N	t	Carretera	\N
2d265829-64a5-4133-8456-8788bf9a896b	2026-01-18 22:10:04.622	2026-01-18 22:10:04.622	\N	t	Por carretera	refresco
\.


--
-- Data for Name: traza; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.traza (id, ip, url, "nombreControlador", traza) FROM stdin;
\.


--
-- Data for Name: um; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.um (id, "updatedAt", "createdAt", _deleted_at, "isActive", name, description, "isUsed", "tipoUmId") FROM stdin;
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.user_roles (id, "updatedAt", "createdAt", _deleted_at, "isActive", "roleId", "userId") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: tmsdb
--

COPY public.users (id, "updatedAt", "createdAt", _deleted_at, "isActive", name, hash, email, description, username, lastname, phone, photo, "isLogged", comercial_code, role) FROM stdin;
b1a62649-8f51-47e9-99d3-3aa080126bf6	2025-08-02 16:08:17.338	2025-08-02 16:08:17.338	\N	t	Dariel	$argon2id$v=19$m=65536,t=3,p=4$PoMAUdV0bB4O36yBY3UmNA$4uviT/Ehh5FaX+8FLJOPrKS4jfYd0GkN0X/SHiPwdLc	tmsadmin@example.com	\N	tmsadmin@example.com	Lazo	+53 55651998	\N	f	\N	792e024b-f781-4f39-ba6a-2445fc1db712
db1ed43d-aba6-47e7-a83b-f57b5f38c6c4	2025-09-18 15:17:08.610714	2025-08-12 05:23:53.184	\N	t	Hassan	$argon2id$v=19$m=65536,t=3,p=4$RwLz5dkVWntXXwi8vGfZzQ$zPEqbiNk2yAtrnVsgAAuca7XIjt/X9xGJFd80+s2yME	hassan@gmail.com	\N	hassan@gmail.com	Acubamos Test	+5354647490	\N	f	0	31007a7f-b624-4bf9-b4d4-a296c46e083d
4b097939-a723-44d6-ad1c-2b069dd5f8c4	2026-05-01 21:23:53.159681	2025-08-14 04:32:08.207	\N	t	Ariel	$argon2id$v=19$m=65536,t=3,p=4$BQgTmkEzzDn5oi+7oTbCbQ$wKP69J3opuJc1lDbLnkE2SAIyOELKGlkDCvChU6rVzQ	redes@acubamos.cu	\N	redes@acubamos.cu	Acubamos Test	+5357585958	\N	f	0	31007a7f-b624-4bf9-b4d4-a296c46e083d
1cecc249-b59e-4c68-9b87-85a2e98dd8ee	2026-05-02 01:19:43.809897	2025-09-03 06:38:18.082	\N	t	Alejandro	$argon2id$v=19$m=65536,t=3,p=4$CQDacR8TrHT6a4V36cjXcw$hj3MZncStILxAH0MXgcuUWCNamQ7CXgStZLzjpWyAhw	alejandro@gmail.com	\N	alejandro@gmail.com	Acubamos Test	+5356575353	\N	f	0	cc42a0e2-f339-495b-b147-ab1e53cbdf7d
82a806d2-2f4f-4857-8460-d762da2e694b	2026-05-04 15:55:45.629897	2025-09-11 05:12:03.319	\N	t	Agencia Nova	$argon2id$v=19$m=65536,t=3,p=4$EfVf8rpWytQWvvdSkk3k6A$QZucS/fTKJqP5xZ41DSpxZcEFYiXbc4Ruqu+ZvW+EzQ	nova@gmail.com	\N	nova@gmail.com	Nova Cuba	+5354748494	\N	f	0	cc42a0e2-f339-495b-b147-ab1e53cbdf7d
698b5a78-92db-4076-8e28-55f5c6e27f69	2025-09-23 10:16:41.225638	2025-09-11 05:12:03.319	\N	t	Mypime F&F	$argon2id$v=19$m=65536,t=3,p=4$08XTwVTlOOhRReEaU9/dmw$Y0k1KHzvVRNXaLdYdvvUI3ovImGsAnP7bNa5JqwVOrc	fast@gmail.com	\N	fast@gmail.com	Fast and Furious	+5355585950	\N	f	0	cc42a0e2-f339-495b-b147-ab1e53cbdf7d
53af6439-898e-4ac9-8256-6952b0326e7a	2026-05-05 14:46:13.526	2026-05-05 14:46:13.527	\N	t	Rosca	$argon2id$v=19$m=65536,t=3,p=4$XR7mj60ZlgHCMygKOsnaKw$DigPDuNuUUODbO7gYFvIG7LHqbpPU2R7Pqba8a9R410	rosca@acubamos.net	\N	rosca@acubamos.net	Izquierdo Suares	+5372940832	\N	f	0	cc42a0e2-f339-495b-b147-ab1e53cbdf7d
a6c78d3b-83d4-446f-8529-50b793f91285	2025-10-20 05:26:21.335	2025-10-20 05:26:21.336	\N	t	Test	$argon2id$v=19$m=65536,t=3,p=4$hG/vwG3ssODTfRUqBXQoTQ$zQMpDWXce1qEdUO4VyrArdPLkHD1FfUdMoydqLJuaxA	test@gmail.com	\N	test@gmail.com	TEST	+5357585950	\N	f	0	cc42a0e2-f339-495b-b147-ab1e53cbdf7d
48564711-cdba-44b3-a187-24be2578e74a	2025-10-20 05:26:21.335	2025-10-20 05:26:21.336	\N	t	CLIENTE	$argon2id$v=19$m=65536,t=3,p=4$/Q9PGJS+/u0/hVd2JARkmA$K3fVQC8WJc8C1Zg+IGdAv1YsiZWzbRvbdmyLxN5kAYM	cliente@gmail.com	\N	cliente@gmail.com	CLIENTE	+5358595758	\N	f	0	31007a7f-b624-4bf9-b4d4-a296c46e083d
45f28bf4-2268-4f7e-93ba-1f9176f62bfe	2026-08-13 14:57:48.444832	2025-10-24 09:12:11.531	\N	t	Pepe	$argon2id$v=19$m=65536,t=3,p=4$vhiRCmwsuWGgiq9j9DnuPg$pCgpavsxA+KIcbaM61WwGXm4CZH+vDaLg3lzl3ZD1zg	pepe@gmail.com	\N	pepe@gmail.com	Perez	+5358595059	\N	f	0	31007a7f-b624-4bf9-b4d4-a296c46e083d
55454c37-5700-4f42-9597-dfd19efd0ad2	2026-07-23 14:14:34.492807	2025-09-11 05:12:03.319	\N	t	ENSA	$argon2id$v=19$m=65536,t=3,p=4$w2+aAx7SoYupyz23hGaXZA$LmWaxjYs4AHxM6IDZURYvj7h4OzBgK13Qn1209u+jRU	ensa@gmail.com	\N	ensa@gmail.com	Empresa Nacional de Servicios Aéreos	+5355585950	\N	f	0	cc42a0e2-f339-495b-b147-ab1e53cbdf7d
5eb51ff5-1f8f-403f-9857-3611c76249f0	2025-10-30 04:33:50.146	2025-10-30 04:33:50.146	\N	t	cliente	$argon2id$v=19$m=65536,t=3,p=4$Bwx9lAa96HkYWi3eYS4LKA$Je2Wl5LtTVK0Lkg/MRjkYJ5tQliFtMIX/SIqA8PQbI8	clientegcom@gmail.com	\N	clientegcom	gcom	+5351234567	\N	f	0	31007a7f-b624-4bf9-b4d4-a296c46e083d
6412345c-5baa-4f69-a436-ea0c6a186972	2025-11-01 11:55:06.576507	2025-10-24 14:29:46.449	\N	t	Ramon	$argon2id$v=19$m=65536,t=3,p=4$QHEjkCuuE90JroSATA4ELQ$vrSCd7afXu3eumPkhAe5Lr3PKpME8BwN/SPo6Xzsbd8	rr@gmail.com	\N	rr@gmail.com	Rodriguez	+5354711145	\N	f	0	cc42a0e2-f339-495b-b147-ab1e53cbdf7d
fadbeabf-c783-430f-9681-8d3118089f37	2025-12-27 00:22:24.341	2025-12-27 00:22:24.342	\N	t	Raonel	$argon2id$v=19$m=65536,t=3,p=4$3ssHn8fWlGsX0cZ6ypbC4A$Ow26hQlfyU2lSqDi/kNh+T6z5Uq2SDwoGrSlwLaQWjw	raonelg66@gmail.com	\N	raonelg66@gmail.com	G	+5355555555	\N	f	0	792e024b-f781-4f39-ba6a-2445fc1db712
49041db6-0a38-4678-a195-5e1ab02222b2	2026-08-13 14:32:56.305146	2025-09-03 06:38:18.082	\N	t	Amel	$argon2id$v=19$m=65536,t=3,p=4$+sET/sfJ80mTOrmbhEuDIg$8I7YZF04sdbfU6ynyRyUvRrKVTrm+fwRo8KUg2bgQRE	amel@gmail.com	\N	amel@gmail.com	Acubamos Test	+5358595758	\N	f	0	cc42a0e2-f339-495b-b147-ab1e53cbdf7d
\.


--
-- Name: peticion PK_10a278d11263d54a05b7b21370d; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.peticion
    ADD CONSTRAINT "PK_10a278d11263d54a05b7b21370d" PRIMARY KEY (id);


--
-- Name: cuenta_bancaria PK_11e663602fe43913128b03d919a; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.cuenta_bancaria
    ADD CONSTRAINT "PK_11e663602fe43913128b03d919a" PRIMARY KEY (id);


--
-- Name: modalidad PK_13ded8f543ee9dc2c6254b85b27; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.modalidad
    ADD CONSTRAINT "PK_13ded8f543ee9dc2c6254b85b27" PRIMARY KEY (id);


--
-- Name: cliente PK_18990e8df6cf7fe71b9dc0f5f39; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT "PK_18990e8df6cf7fe71b9dc0f5f39" PRIMARY KEY (id);


--
-- Name: proveedores PK_1dcf121f19f362fb1b4c0a493a9; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.proveedores
    ADD CONSTRAINT "PK_1dcf121f19f362fb1b4c0a493a9" PRIMARY KEY (id);


--
-- Name: destino PK_219948e1be8872a166851326eb2; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.destino
    ADD CONSTRAINT "PK_219948e1be8872a166851326eb2" PRIMARY KEY (id);


--
-- Name: plan-servicio-prestatario PK_21c5579a9a708ce2a50b4763363; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public."plan-servicio-prestatario"
    ADD CONSTRAINT "PK_21c5579a9a708ce2a50b4763363" PRIMARY KEY (id);


--
-- Name: um PK_236327ad06de81deb8b2455e709; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.um
    ADD CONSTRAINT "PK_236327ad06de81deb8b2455e709" PRIMARY KEY (id);


--
-- Name: calendar PK_2492fb846a48ea16d53864e3267; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.calendar
    ADD CONSTRAINT "PK_2492fb846a48ea16d53864e3267" PRIMARY KEY (id);


--
-- Name: municipality PK_281ad341f20df7c41b83a182e2a; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.municipality
    ADD CONSTRAINT "PK_281ad341f20df7c41b83a182e2a" PRIMARY KEY (id);


--
-- Name: plan-servicio-cliente PK_284c9935b497cb74baeb44aad20; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public."plan-servicio-cliente"
    ADD CONSTRAINT "PK_284c9935b497cb74baeb44aad20" PRIMARY KEY (id);


--
-- Name: reserva PK_37909c9a3ea6a72ee6f21b16129; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.reserva
    ADD CONSTRAINT "PK_37909c9a3ea6a72ee6f21b16129" PRIMARY KEY (id);


--
-- Name: tipoviaje PK_37e99f7d9f834eea5caa0f19e5c; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.tipoviaje
    ADD CONSTRAINT "PK_37e99f7d9f834eea5caa0f19e5c" PRIMARY KEY (id);


--
-- Name: tipotransporte PK_3c10e87a4d8831a004b810b2a12; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.tipotransporte
    ADD CONSTRAINT "PK_3c10e87a4d8831a004b810b2a12" PRIMARY KEY (id);


--
-- Name: configuracion PK_42615c5e55d08746ae5accfc295; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.configuracion
    ADD CONSTRAINT "PK_42615c5e55d08746ae5accfc295" PRIMARY KEY (id);


--
-- Name: doccarga PK_466292b4787cf07cb3b72a7dcd2; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.doccarga
    ADD CONSTRAINT "PK_466292b4787cf07cb3b72a7dcd2" PRIMARY KEY (id);


--
-- Name: province PK_4f461cb46f57e806516b7073659; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.province
    ADD CONSTRAINT "PK_4f461cb46f57e806516b7073659" PRIMARY KEY (id);


--
-- Name: tipopago PK_5cb87d7cf85ce05524a0fa69cf0; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.tipopago
    ADD CONSTRAINT "PK_5cb87d7cf85ce05524a0fa69cf0" PRIMARY KEY (id);


--
-- Name: prestatarios PK_5e8a4c60ce7252722133e954de0; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.prestatarios
    ADD CONSTRAINT "PK_5e8a4c60ce7252722133e954de0" PRIMARY KEY (id);


--
-- Name: cita_taller PK_66f48958618d990299ca384039f; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.cita_taller
    ADD CONSTRAINT "PK_66f48958618d990299ca384039f" PRIMARY KEY (id);


--
-- Name: notifications PK_6a72c3c0f683f6462415e653c3a; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT "PK_6a72c3c0f683f6462415e653c3a" PRIMARY KEY (id);


--
-- Name: pago PK_6be14be998d5e41f10e58c0e651; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.pago
    ADD CONSTRAINT "PK_6be14be998d5e41f10e58c0e651" PRIMARY KEY (id);


--
-- Name: origen PK_7662a7d3fd66fba6f08906ba897; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.origen
    ADD CONSTRAINT "PK_7662a7d3fd66fba6f08906ba897" PRIMARY KEY (id);


--
-- Name: taller_horario PK_7ad565c4f70fcfb72c692e1b670; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.taller_horario
    ADD CONSTRAINT "PK_7ad565c4f70fcfb72c692e1b670" PRIMARY KEY (id);


--
-- Name: address_details PK_7c8b46f60b66d03c22f1531b3af; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.address_details
    ADD CONSTRAINT "PK_7c8b46f60b66d03c22f1531b3af" PRIMARY KEY (id);


--
-- Name: user_roles PK_8acd5cf26ebd158416f477de799; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT "PK_8acd5cf26ebd158416f477de799" PRIMARY KEY (id);


--
-- Name: tipos_um PK_8bbbdc3d9fe181bc67d5b874ed2; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.tipos_um
    ADD CONSTRAINT "PK_8bbbdc3d9fe181bc67d5b874ed2" PRIMARY KEY (id);


--
-- Name: solicitudes PK_8c7e99758c774b801853b538647; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.solicitudes
    ADD CONSTRAINT "PK_8c7e99758c774b801853b538647" PRIMARY KEY (id);


--
-- Name: planes PK_91be19f449ba03767fe51acdebc; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.planes
    ADD CONSTRAINT "PK_91be19f449ba03767fe51acdebc" PRIMARY KEY (id);


--
-- Name: proposals_alquiler PK_94109fcdef4449460b1c87536cf; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.proposals_alquiler
    ADD CONSTRAINT "PK_94109fcdef4449460b1c87536cf" PRIMARY KEY (id);


--
-- Name: tipomercado PK_9671407bb221014dd0f3357efdc; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.tipomercado
    ADD CONSTRAINT "PK_9671407bb221014dd0f3357efdc" PRIMARY KEY (id);


--
-- Name: traza PK_9c9e2df5aa69e52f3ef752c801c; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.traza
    ADD CONSTRAINT "PK_9c9e2df5aa69e52f3ef752c801c" PRIMARY KEY (id);


--
-- Name: customer_cuenta PK_9e93fe253c36298dc0a5819acc9; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.customer_cuenta
    ADD CONSTRAINT "PK_9e93fe253c36298dc0a5819acc9" PRIMARY KEY (id);


--
-- Name: users PK_a3ffb1c0c8416b9fc6f907b7433; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "PK_a3ffb1c0c8416b9fc6f907b7433" PRIMARY KEY (id);


--
-- Name: servicio PK_a589f335f4fc94f913c9f86e608; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.servicio
    ADD CONSTRAINT "PK_a589f335f4fc94f913c9f86e608" PRIMARY KEY (id);


--
-- Name: customer PK_a7a13f4cacb744524e44dfdad32; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT "PK_a7a13f4cacb744524e44dfdad32" PRIMARY KEY (id);


--
-- Name: prestatario PK_be03854e44b62eea66421911380; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.prestatario
    ADD CONSTRAINT "PK_be03854e44b62eea66421911380" PRIMARY KEY (id);


--
-- Name: country PK_bf6e37c231c4f4ea56dcd887269; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.country
    ADD CONSTRAINT "PK_bf6e37c231c4f4ea56dcd887269" PRIMARY KEY (id);


--
-- Name: locality PK_c0445d9b8706ac2d31be91c9b6b; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.locality
    ADD CONSTRAINT "PK_c0445d9b8706ac2d31be91c9b6b" PRIMARY KEY (id);


--
-- Name: roles PK_c1433d71a4838793a49dcad46ab; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT "PK_c1433d71a4838793a49dcad46ab" PRIMARY KEY (id);


--
-- Name: tipocarga PK_c43296c0486e91efc0001e90271; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.tipocarga
    ADD CONSTRAINT "PK_c43296c0486e91efc0001e90271" PRIMARY KEY (id);


--
-- Name: proposal PK_ca872ecfe4fef5720d2d39e4275; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.proposal
    ADD CONSTRAINT "PK_ca872ecfe4fef5720d2d39e4275" PRIMARY KEY (id);


--
-- Name: taller_servicio PK_cd9f1b70885efbdbc1d3e6cc38f; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.taller_servicio
    ADD CONSTRAINT "PK_cd9f1b70885efbdbc1d3e6cc38f" PRIMARY KEY (id);


--
-- Name: prestatarioserv PK_dd17fcb62208adeb9158bd36a36; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.prestatarioserv
    ADD CONSTRAINT "PK_dd17fcb62208adeb9158bd36a36" PRIMARY KEY (id);


--
-- Name: comercial PK_e6544a966eec6e3e2d1c4c19b54; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.comercial
    ADD CONSTRAINT "PK_e6544a966eec6e3e2d1c4c19b54" PRIMARY KEY (id);


--
-- Name: proposals_services PK_ed591ebb4b96ba6496d849b5d4d; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.proposals_services
    ADD CONSTRAINT "PK_ed591ebb4b96ba6496d849b5d4d" PRIMARY KEY (id);


--
-- Name: carga PK_ee596364b828e52f8207d2829a4; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.carga
    ADD CONSTRAINT "PK_ee596364b828e52f8207d2829a4" PRIMARY KEY (id);


--
-- Name: tipo_servicio_mecanico PK_f525a70d76a890b4a4c2a9c356d; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.tipo_servicio_mecanico
    ADD CONSTRAINT "PK_f525a70d76a890b4a4c2a9c356d" PRIMARY KEY (id);


--
-- Name: setting PK_fcb21187dc6094e24a48f677bed; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.setting
    ADD CONSTRAINT "PK_fcb21187dc6094e24a48f677bed" PRIMARY KEY (id);


--
-- Name: cliente REL_1abba09fd4376b65247f23a4a8; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT "REL_1abba09fd4376b65247f23a4a8" UNIQUE (user_id);


--
-- Name: peticion REL_aeee983c02ca0880ad8261c74d; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.peticion
    ADD CONSTRAINT "REL_aeee983c02ca0880ad8261c74d" UNIQUE (assigned_proposal_id);


--
-- Name: prestatarios REL_c73462bff0e33f9d605a06dbb8; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.prestatarios
    ADD CONSTRAINT "REL_c73462bff0e33f9d605a06dbb8" UNIQUE (user_id);


--
-- Name: prestatario UQ_0a8701f59f484a2cd208b58285c; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.prestatario
    ADD CONSTRAINT "UQ_0a8701f59f484a2cd208b58285c" UNIQUE ("user");


--
-- Name: carga UQ_0f43b42856ba9af20ae35e0dc21; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.carga
    ADD CONSTRAINT "UQ_0f43b42856ba9af20ae35e0dc21" UNIQUE (carga_serie);


--
-- Name: carga UQ_2bffd08a8e9744b690ca42d9ba0; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.carga
    ADD CONSTRAINT "UQ_2bffd08a8e9744b690ca42d9ba0" UNIQUE (order_id);


--
-- Name: tipo_servicio_mecanico UQ_4d19b203c2fd407525ebc42dc24; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.tipo_servicio_mecanico
    ADD CONSTRAINT "UQ_4d19b203c2fd407525ebc42dc24" UNIQUE (codigo);


--
-- Name: country UQ_8ff4c23dc9a3f3856555bd86186; Type: CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.country
    ADD CONSTRAINT "UQ_8ff4c23dc9a3f3856555bd86186" UNIQUE (code);


--
-- Name: IDX_0a8701f59f484a2cd208b58285; Type: INDEX; Schema: public; Owner: tmsdb
--

CREATE UNIQUE INDEX "IDX_0a8701f59f484a2cd208b58285" ON public.prestatario USING btree ("user");


--
-- Name: IDX_1c4c95d773004250c157a744d6; Type: INDEX; Schema: public; Owner: tmsdb
--

CREATE UNIQUE INDEX "IDX_1c4c95d773004250c157a744d6" ON public.setting USING btree (key);


--
-- Name: IDX_293e17edbe01ae7c1b559b220c; Type: INDEX; Schema: public; Owner: tmsdb
--

CREATE INDEX "IDX_293e17edbe01ae7c1b559b220c" ON public.cita_taller USING btree (taller_id);


--
-- Name: IDX_42b29380f16e3186328f8f7c57; Type: INDEX; Schema: public; Owner: tmsdb
--

CREATE INDEX "IDX_42b29380f16e3186328f8f7c57" ON public.cita_taller USING btree (cliente_id);


--
-- Name: IDX_c73462bff0e33f9d605a06dbb8; Type: INDEX; Schema: public; Owner: tmsdb
--

CREATE UNIQUE INDEX "IDX_c73462bff0e33f9d605a06dbb8" ON public.prestatarios USING btree (user_id);


--
-- Name: IDX_dce0d1ec2708f900f5298a6d2f; Type: INDEX; Schema: public; Owner: tmsdb
--

CREATE INDEX "IDX_dce0d1ec2708f900f5298a6d2f" ON public.solicitudes USING btree (service_requested);


--
-- Name: IDX_ddcf32bb6f85ffcb1b01cfd547; Type: INDEX; Schema: public; Owner: tmsdb
--

CREATE INDEX "IDX_ddcf32bb6f85ffcb1b01cfd547" ON public.prestatarioserv USING btree (prestatario_id, servicio_id, "isActive") WHERE ("isActive" = true);


--
-- Name: cita_taller FK_02ed71783ef417080faed8f029c; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.cita_taller
    ADD CONSTRAINT "FK_02ed71783ef417080faed8f029c" FOREIGN KEY (destino_id) REFERENCES public.address_details(id) ON DELETE SET NULL;


--
-- Name: proposals_services FK_0a614c742b86a6fc4ade102101e; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.proposals_services
    ADD CONSTRAINT "FK_0a614c742b86a6fc4ade102101e" FOREIGN KEY (prestatario_id) REFERENCES public.prestatario(id);


--
-- Name: prestatario FK_0a8701f59f484a2cd208b58285c; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.prestatario
    ADD CONSTRAINT "FK_0a8701f59f484a2cd208b58285c" FOREIGN KEY ("user") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notifications FK_105f64385aa81cdde8870999852; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT "FK_105f64385aa81cdde8870999852" FOREIGN KEY (user_origin_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: cita_taller FK_12744bdee62a8fc3b5e1feb8259; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.cita_taller
    ADD CONSTRAINT "FK_12744bdee62a8fc3b5e1feb8259" FOREIGN KEY (tipo_transporte_id) REFERENCES public.tipotransporte(id) ON DELETE SET NULL;


--
-- Name: doccarga FK_12a52de3c281893761b3d5ef26d; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.doccarga
    ADD CONSTRAINT "FK_12a52de3c281893761b3d5ef26d" FOREIGN KEY (carga) REFERENCES public.carga(id);


--
-- Name: locality FK_1381e70599f441e568cac6ac98a; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.locality
    ADD CONSTRAINT "FK_1381e70599f441e568cac6ac98a" FOREIGN KEY (municipality_id) REFERENCES public.municipality(id);


--
-- Name: plan-servicio-cliente FK_142a42541c44f2c1e62ab09ecaf; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public."plan-servicio-cliente"
    ADD CONSTRAINT "FK_142a42541c44f2c1e62ab09ecaf" FOREIGN KEY (plan_id) REFERENCES public.planes(id);


--
-- Name: cita_taller FK_182392936516b34c710a9ba58b6; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.cita_taller
    ADD CONSTRAINT "FK_182392936516b34c710a9ba58b6" FOREIGN KEY (servicio_id) REFERENCES public.taller_servicio(id) ON DELETE SET NULL;


--
-- Name: cliente FK_1abba09fd4376b65247f23a4a86; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT "FK_1abba09fd4376b65247f23a4a86" FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: carga FK_20362a2b27cc583fff058657d08; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.carga
    ADD CONSTRAINT "FK_20362a2b27cc583fff058657d08" FOREIGN KEY (origen) REFERENCES public.origen(id);


--
-- Name: peticion FK_232a49bebdc77817d9fb9d16ba9; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.peticion
    ADD CONSTRAINT "FK_232a49bebdc77817d9fb9d16ba9" FOREIGN KEY (transportista_prestatario_id) REFERENCES public.prestatario(id);


--
-- Name: solicitudes FK_25ce61e19829efada40e96dfa64; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.solicitudes
    ADD CONSTRAINT "FK_25ce61e19829efada40e96dfa64" FOREIGN KEY (cliente_id) REFERENCES public.cliente(id) ON DELETE SET NULL;


--
-- Name: cita_taller FK_293e17edbe01ae7c1b559b220cc; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.cita_taller
    ADD CONSTRAINT "FK_293e17edbe01ae7c1b559b220cc" FOREIGN KEY (taller_id) REFERENCES public.prestatario(id) ON DELETE CASCADE;


--
-- Name: pago FK_2f9a05e76e48178e6ffe96018a1; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.pago
    ADD CONSTRAINT "FK_2f9a05e76e48178e6ffe96018a1" FOREIGN KEY (reserva_id) REFERENCES public.reserva(id);


--
-- Name: notifications FK_379865828e5936025b50f6bd0a4; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT "FK_379865828e5936025b50f6bd0a4" FOREIGN KEY (user_target_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: prestatario FK_3fdb5d556f921cd492fdf3ba873; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.prestatario
    ADD CONSTRAINT "FK_3fdb5d556f921cd492fdf3ba873" FOREIGN KEY (taller_direccion_id) REFERENCES public.address_details(id) ON DELETE SET NULL;


--
-- Name: cita_taller FK_416d22163601659bc4da604b36a; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.cita_taller
    ADD CONSTRAINT "FK_416d22163601659bc4da604b36a" FOREIGN KEY (origen_id) REFERENCES public.address_details(id) ON DELETE SET NULL;


--
-- Name: pago FK_42ad66c2f895667d39057aa6bb8; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.pago
    ADD CONSTRAINT "FK_42ad66c2f895667d39057aa6bb8" FOREIGN KEY ("customerId") REFERENCES public.customer(id);


--
-- Name: cita_taller FK_42b29380f16e3186328f8f7c575; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.cita_taller
    ADD CONSTRAINT "FK_42b29380f16e3186328f8f7c575" FOREIGN KEY (cliente_id) REFERENCES public.prestatario(id) ON DELETE CASCADE;


--
-- Name: proposal FK_4391cdb2e1805fac2c6933a01e6; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.proposal
    ADD CONSTRAINT "FK_4391cdb2e1805fac2c6933a01e6" FOREIGN KEY ("prestatarioId") REFERENCES public.prestatario(id);


--
-- Name: reserva FK_4557365e077185968fe8be900e5; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.reserva
    ADD CONSTRAINT "FK_4557365e077185968fe8be900e5" FOREIGN KEY ("comercialId") REFERENCES public.comercial(id);


--
-- Name: user_roles FK_472b25323af01488f1f66a06b67; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT "FK_472b25323af01488f1f66a06b67" FOREIGN KEY ("userId") REFERENCES public.users(id);


--
-- Name: municipality FK_483c51de02d90702f5acb0ddfcd; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.municipality
    ADD CONSTRAINT "FK_483c51de02d90702f5acb0ddfcd" FOREIGN KEY (province_id) REFERENCES public.province(id);


--
-- Name: proposals_alquiler FK_4d7689a8e86240a2b20cc10702b; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.proposals_alquiler
    ADD CONSTRAINT "FK_4d7689a8e86240a2b20cc10702b" FOREIGN KEY ("solicitudId") REFERENCES public.solicitudes(id) ON DELETE CASCADE;


--
-- Name: address_details FK_4e385c94a4430ad4d6d5e70e745; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.address_details
    ADD CONSTRAINT "FK_4e385c94a4430ad4d6d5e70e745" FOREIGN KEY (municipality_id) REFERENCES public.municipality(id);


--
-- Name: carga FK_507b22fabd297ac180803cdaba0; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.carga
    ADD CONSTRAINT "FK_507b22fabd297ac180803cdaba0" FOREIGN KEY (assigned_prestatario_id) REFERENCES public.prestatario(id);


--
-- Name: proposal FK_53f8fa5712cd509ca6232d0dfac; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.proposal
    ADD CONSTRAINT "FK_53f8fa5712cd509ca6232d0dfac" FOREIGN KEY ("cargaId") REFERENCES public.carga(id) ON DELETE CASCADE;


--
-- Name: prestatarioserv FK_572a3243b69076e58c45f199b5e; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.prestatarioserv
    ADD CONSTRAINT "FK_572a3243b69076e58c45f199b5e" FOREIGN KEY (servicio_id) REFERENCES public.servicio(id) ON DELETE CASCADE;


--
-- Name: customer FK_7e918401e086f425b53c6e37818; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.customer
    ADD CONSTRAINT "FK_7e918401e086f425b53c6e37818" FOREIGN KEY (planes_id) REFERENCES public.planes(id);


--
-- Name: taller_horario FK_80eac8d6dba298a9714b5c8dcca; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.taller_horario
    ADD CONSTRAINT "FK_80eac8d6dba298a9714b5c8dcca" FOREIGN KEY (prestatario_id) REFERENCES public.prestatario(id) ON DELETE CASCADE;


--
-- Name: plan-servicio-cliente FK_827287c56c163178ef42b47f578; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public."plan-servicio-cliente"
    ADD CONSTRAINT "FK_827287c56c163178ef42b47f578" FOREIGN KEY (servicio_id) REFERENCES public.servicio(id);


--
-- Name: peticion FK_82b709223c74a9b15cdfaa6aecc; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.peticion
    ADD CONSTRAINT "FK_82b709223c74a9b15cdfaa6aecc" FOREIGN KEY (cliente_id) REFERENCES public.cliente(id);


--
-- Name: user_roles FK_86033897c009fcca8b6505d6be2; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT "FK_86033897c009fcca8b6505d6be2" FOREIGN KEY ("roleId") REFERENCES public.roles(id);


--
-- Name: cita_taller FK_869c21384921f5d6f0cd0f3edf0; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.cita_taller
    ADD CONSTRAINT "FK_869c21384921f5d6f0cd0f3edf0" FOREIGN KEY (tipo_carga_id) REFERENCES public.tipocarga(id) ON DELETE SET NULL;


--
-- Name: proposal FK_8ad4af154889d9586be1d7cbf3a; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.proposal
    ADD CONSTRAINT "FK_8ad4af154889d9586be1d7cbf3a" FOREIGN KEY ("peticionId") REFERENCES public.peticion(id) ON DELETE CASCADE;


--
-- Name: pago FK_8fff6835863c7eded29dbe152e1; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.pago
    ADD CONSTRAINT "FK_8fff6835863c7eded29dbe152e1" FOREIGN KEY ("cuentaBancariaOrigen") REFERENCES public.cuenta_bancaria(id);


--
-- Name: prestatarioserv FK_91dd76953f805c70e0f8c7f3086; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.prestatarioserv
    ADD CONSTRAINT "FK_91dd76953f805c70e0f8c7f3086" FOREIGN KEY (prestatario_id) REFERENCES public.prestatario(id) ON DELETE CASCADE;


--
-- Name: reserva FK_a09b1fa7d9ffa5e85d6031d57ef; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.reserva
    ADD CONSTRAINT "FK_a09b1fa7d9ffa5e85d6031d57ef" FOREIGN KEY ("userId") REFERENCES public.users(id);


--
-- Name: users FK_ace513fa30d485cfd25c11a9e4a; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "FK_ace513fa30d485cfd25c11a9e4a" FOREIGN KEY (role) REFERENCES public.roles(id);


--
-- Name: peticion FK_aeee983c02ca0880ad8261c74d4; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.peticion
    ADD CONSTRAINT "FK_aeee983c02ca0880ad8261c74d4" FOREIGN KEY (assigned_proposal_id) REFERENCES public.proposal(id);


--
-- Name: taller_servicio FK_b1e78686c874df986873dde8f23; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.taller_servicio
    ADD CONSTRAINT "FK_b1e78686c874df986873dde8f23" FOREIGN KEY (prestatario_id) REFERENCES public.prestatario(id) ON DELETE CASCADE;


--
-- Name: pago FK_b504febb33005b6433f5f46854b; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.pago
    ADD CONSTRAINT "FK_b504febb33005b6433f5f46854b" FOREIGN KEY (comercial_id) REFERENCES public.comercial(id);


--
-- Name: proposals_services FK_b836e4e40a18bbd603541c43256; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.proposals_services
    ADD CONSTRAINT "FK_b836e4e40a18bbd603541c43256" FOREIGN KEY (proposer_id) REFERENCES public.users(id);


--
-- Name: proposals_alquiler FK_c32ddeb79df11da04221f57f43c; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.proposals_alquiler
    ADD CONSTRAINT "FK_c32ddeb79df11da04221f57f43c" FOREIGN KEY ("prestatarioId") REFERENCES public.prestatario(id);


--
-- Name: prestatarios FK_c73462bff0e33f9d605a06dbb87; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.prestatarios
    ADD CONSTRAINT "FK_c73462bff0e33f9d605a06dbb87" FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: carga FK_c73a8f4fade0c45eadab31ec9fb; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.carga
    ADD CONSTRAINT "FK_c73a8f4fade0c45eadab31ec9fb" FOREIGN KEY (cliente_id) REFERENCES public.cliente(id);


--
-- Name: proposal FK_d58b1e590e0d18f7b37fba11dde; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.proposal
    ADD CONSTRAINT "FK_d58b1e590e0d18f7b37fba11dde" FOREIGN KEY ("proposerId") REFERENCES public.users(id);


--
-- Name: solicitudes FK_d63f6b66af9878fb0ab0c79e752; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.solicitudes
    ADD CONSTRAINT "FK_d63f6b66af9878fb0ab0c79e752" FOREIGN KEY (assigned_prestatario_id) REFERENCES public.prestatario(id) ON DELETE SET NULL;


--
-- Name: customer_cuenta FK_dae952e20a238a8d2a9809f6c33; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.customer_cuenta
    ADD CONSTRAINT "FK_dae952e20a238a8d2a9809f6c33" FOREIGN KEY (cuenta_bancaria_id) REFERENCES public.cuenta_bancaria(id);


--
-- Name: carga FK_e0bda2f00096fa67a8f27e2cd30; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.carga
    ADD CONSTRAINT "FK_e0bda2f00096fa67a8f27e2cd30" FOREIGN KEY (destino) REFERENCES public.destino(id);


--
-- Name: proposals_alquiler FK_e18d6a5e98766b2d4382054f5b3; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.proposals_alquiler
    ADD CONSTRAINT "FK_e18d6a5e98766b2d4382054f5b3" FOREIGN KEY ("proposerId") REFERENCES public.users(id);


--
-- Name: province FK_e1a4eb156aedf1714d673d13941; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.province
    ADD CONSTRAINT "FK_e1a4eb156aedf1714d673d13941" FOREIGN KEY (country_id) REFERENCES public.country(id);


--
-- Name: customer_cuenta FK_eb8a94a8b28761842d1562bbc1c; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.customer_cuenta
    ADD CONSTRAINT "FK_eb8a94a8b28761842d1562bbc1c" FOREIGN KEY (customer_id) REFERENCES public.customer(id);


--
-- Name: proposals_services FK_ed8b6dd285bdad578f9b9be02c5; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.proposals_services
    ADD CONSTRAINT "FK_ed8b6dd285bdad578f9b9be02c5" FOREIGN KEY (solicitud_id) REFERENCES public.solicitudes(id) ON DELETE CASCADE;


--
-- Name: solicitudes FK_faf5bc4c2ab7c08672c09d06216; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.solicitudes
    ADD CONSTRAINT "FK_faf5bc4c2ab7c08672c09d06216" FOREIGN KEY (created_by_prestatario_id) REFERENCES public.prestatario(id) ON DELETE SET NULL;


--
-- Name: um FK_fcf011350fc58fc03daf9c33c31; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.um
    ADD CONSTRAINT "FK_fcf011350fc58fc03daf9c33c31" FOREIGN KEY ("tipoUmId") REFERENCES public.tipos_um(id);


--
-- Name: reserva FK_ffba5b7cd489b8bd63f76320f5a; Type: FK CONSTRAINT; Schema: public; Owner: tmsdb
--

ALTER TABLE ONLY public.reserva
    ADD CONSTRAINT "FK_ffba5b7cd489b8bd63f76320f5a" FOREIGN KEY ("servicioId") REFERENCES public.servicio(id);


--
-- PostgreSQL database dump complete
--

\unrestrict NRlzwTe2eo3F7rZHIjHeJgmBPEszYauRCY27zKSOcqqsdEove0ZgzY3fhycguxY

